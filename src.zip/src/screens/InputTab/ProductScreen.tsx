// src/screens/InputTab/ProductScreen.tsx
import React, { useState, useEffect, useCallback, useLayoutEffect, lazy, Suspense } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Platform, ScrollView, TouchableOpacity } from 'react-native';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import type { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { addDays } from 'date-fns';

import { InputStackNavigatorParamList } from '../../navigation/types';
import { theme } from '../../theme';
import { ProductionEntry, UserSelectedQuota } from '../../types/data';
import { supabase } from '../../services/supabase';
import {
  getQuotaSettingByProductCode,
  getQuotaValueBySalaryLevel,
  updateProductionEntryById,
  deleteProductionEntry,
} from '../../services/storage';
import { getToday, formatToYYYYMMDD } from '../../utils/dateUtils';
import WeeklyPage from './components/WeeklyPage';
import Button from '../../components/common/Button';
import AlertModal, { AlertButtonType } from '../../components/common/AlertModal';
import SelectProductModal from './components/SelectProductModal';
import EditEntryModal from './components/EditEntryModal';
import { useProductionStore } from '../../stores/productionStore';

if (Platform.OS === 'web') {
  const styleId = 'hide-scrollbar-style';
  if (!document.getElementById(styleId)) {
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `.scrollable-slide::-webkit-scrollbar { display: none; } .scrollable-slide { -ms-overflow-style: none; scrollbar-width: none; }`;
    document.head.appendChild(style);
  }
}

const PagerView = Platform.OS !== 'web' ? lazy(() => import('react-native-pager-view')) : null;
type ProductScreenNavigationProp = StackNavigationProp<InputStackNavigatorParamList, 'ProductList'>;
export interface ProcessedWeekData {
  weekInfo: import('../../utils/dateUtils').EstronWeekPeriod;
  dailyData: import('../../types/data').DailyProductionData[];
  totalWeeklyWork: number;
}

export default function ProductScreen() {
  const navigation = useNavigation<ProductScreenNavigationProp>();

  const {
    userProfile,
    userSelectedQuotas,
    processedWeeksData,
    estronWeekInfo,
    isLoading,
    targetDate,
    isViewingPreviousMonth,
    currentPageIndex,
    setCurrentPageIndex,
    initialize,
    cleanup,
    setTargetDate,
  } = useProductionStore();

  const [userId, setUserId] = useState<string | null>(null);
  const [selectedDateForInput, setSelectedDateForInput] = useState<string>(formatToYYYYMMDD(getToday()));
  const [isSaving, setIsSaving] = useState(false);
  const [isProductModalVisible, setIsProductModalVisible] = useState(false);
  const [isEditModalVisible, setIsEditModalVisible] = useState(false);
  const [editingEntry, setEditingEntry] = useState<ProductionEntry | null>(null);
  const [isCustomAlertVisible, setIsCustomAlertVisible] = useState(false);
  const [customAlertMessage, setCustomAlertMessage] = useState('');
  const [customAlertButtons, setCustomAlertButtons] = useState<AlertButtonType[]>([]);

  const showAlert = (message: string, buttons?: AlertButtonType[]) => {
    setCustomAlertMessage(message);
    setCustomAlertButtons(buttons || [{ text: 'OK', onPress: () => setIsCustomAlertVisible(false) }]);
    setIsCustomAlertVisible(true);
  };
  const closeAlert = () => setIsCustomAlertVisible(false);

  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user) setUserId(user.id);
      else showAlert('Không tìm thấy thông tin người dùng để tải dữ liệu.');
    };
    fetchUser();
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (userId) {
        initialize(userId);
      }
      return () => {
        cleanup();
      };
    }, [userId, initialize, cleanup])
  );

  const handleNavigateToPreviousMonth = useCallback(() => {
    if (estronWeekInfo) {
      const previousMonthDate = addDays(estronWeekInfo.estronMonth.startDate, -1);
      setTargetDate(previousMonthDate);
    }
  }, [estronWeekInfo, setTargetDate]);

  const handleNavigateToCurrentMonth = useCallback(() => {
    setTargetDate(getToday());
  }, [setTargetDate]);

  useLayoutEffect(() => {
    if (estronWeekInfo) {
      navigation.setOptions({
        title: `Sản lượng tháng ${estronWeekInfo.estronMonth.estronMonth}`,
        headerLeft: () => (
          <TouchableOpacity
            onPress={isViewingPreviousMonth ? handleNavigateToCurrentMonth : handleNavigateToPreviousMonth}
            style={{
              marginLeft: Platform.OS === 'ios' ? theme.spacing['level-2'] : theme.spacing['level-4'],
              padding: theme.spacing['level-1'],
            }}
          >
            <Ionicons
              name={isViewingPreviousMonth ? 'caret-forward' : 'caret-back'}
              size={26}
              color={theme.colors.textOnPrimary}
            />
          </TouchableOpacity>
        ),
      });
    } else {
      navigation.setOptions({ title: 'Sản Lượng Estron', headerLeft: () => null });
    }
  }, [navigation, estronWeekInfo, isViewingPreviousMonth, handleNavigateToPreviousMonth, handleNavigateToCurrentMonth]);

  const handleSelectProduct = async (selectedUserQuota: UserSelectedQuota) => {
    setIsProductModalVisible(false);
    if (!userProfile || !userProfile.salary_level) {
      showAlert('Không tìm thấy thông tin bậc lương người dùng.');
      return;
    }
    if (!selectedUserQuota.product_code) {
      showAlert('Mã sản phẩm không hợp lệ.');
      return;
    }
    const { data: quotaSettingDetails, error } = await getQuotaSettingByProductCode(selectedUserQuota.product_code);
    if (error) {
      showAlert(`Lỗi khi lấy định mức: ${error.message}`);
      return;
    }
    if (!quotaSettingDetails) {
      showAlert(`Không tìm thấy chi tiết định mức cho sản phẩm '${selectedUserQuota.product_code}'.`);
      return;
    }
    const actualQuotaValue = getQuotaValueBySalaryLevel(quotaSettingDetails, userProfile.salary_level);
    navigation.navigate('InputDetails', {
      stageCode: selectedUserQuota.product_code,
      quotaValue: actualQuotaValue,
      date: selectedDateForInput,
    });
  };
  const openProductModal = (dateForInput: string) => {
    if (userSelectedQuotas.length === 0) {
      showAlert('Bạn chưa chọn sản phẩm nào trong phần Cài Đặt Định Mức.');
      return;
    }
    setSelectedDateForInput(dateForInput);
    setIsProductModalVisible(true);
  };
  const handleOpenEditModal = (entry: ProductionEntry) => {
    if (entry.verified) {
      showAlert('Mục này đã được xác nhận và không thể sửa.');
      return;
    }
    setEditingEntry(entry);
    setIsEditModalVisible(true);
  };
  const handleCloseEditModal = () => {
    setIsEditModalVisible(false);
    setEditingEntry(null);
  };
  const handleUpdateEntry = async (updatedData: Partial<Omit<ProductionEntry, 'id'>>) => {
    if (!editingEntry) return;
    if (
      updatedData.quantity !== undefined &&
      updatedData.quantity !== null &&
      (isNaN(updatedData.quantity) || updatedData.quantity < 0)
    ) {
      showAlert('Số lượng phải là một số không âm.');
      return;
    }
    setIsSaving(true);
    const { data: updatedEntry, error } = await updateProductionEntryById(editingEntry.id, updatedData);
    setIsSaving(false);
    if (error) {
      showAlert(`Lỗi cập nhật: ${error.message}`);
    } else if (updatedEntry) {
      showAlert('Đã cập nhật thông tin sản phẩm.');
      handleCloseEditModal();
    }
  };
  const handleDeleteEntry = (entry: ProductionEntry) => {
    if (!entry) return;
    const message = `Xác nhận xóa\n\nBạn có chắc chắn muốn xóa mục sản phẩm "${entry.product_code}" với số lượng ${entry.quantity ?? 'N/A'} không?`;
    showAlert(message, [
      { text: 'Hủy', style: 'secondary', onPress: closeAlert },
      {
        text: 'Xóa',
        style: 'danger',
        onPress: async () => {
          closeAlert();
          setIsSaving(true);
          const { data: success, error } = await deleteProductionEntry(entry.id);
          setIsSaving(false);
          if (error) {
            showAlert(`Lỗi xóa: ${error.message}`);
          } else if (success) {
            showAlert('Mục sản phẩm đã được xóa.');
            handleCloseEditModal();
          }
        },
      },
    ]);
  };

  if (isLoading && processedWeeksData.length === 0) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
        <Text style={{ color: theme.colors.textSecondary, marginTop: theme.spacing['level-2'] }}>
          Đang tải dữ liệu...
        </Text>
      </View>
    );
  }
  if (!userId && !isLoading) {
    return (
      <View style={styles.centered}>
        <Text style={styles.emptyText}>Không thể tải dữ liệu do chưa xác thực người dùng.</Text>
      </View>
    );
  }
  if (userId && !isLoading && (!estronWeekInfo || processedWeeksData.length === 0)) {
    return (
      <View style={styles.centered}>
        <Text style={styles.emptyText}>Không có dữ liệu tuần để hiển thị cho tháng này.</Text>
        <Button title="Tải lại" onPress={() => initialize(userId)} style={{ marginTop: theme.spacing['level-4'] }} />
      </View>
    );
  }

  const pagerKey = `${userId}-${processedWeeksData.length}-${currentPageIndex}-${Platform.OS}-${targetDate.toISOString()}`;

  return (
    <View style={styles.container}>
      {userId &&
        processedWeeksData.length > 0 &&
        (Platform.OS === 'web' ? (
          <Swiper
            style={styles.pagerView}
            initialSlide={currentPageIndex}
            onSlideChange={swiper => setCurrentPageIndex(swiper.activeIndex)}
            key={pagerKey}
            // *** THAY ĐỔI DUY NHẤT NẰM Ở ĐÂY ***
            // Tăng thời gian chuyển slide để tạo hiệu ứng slow motion (đơn vị: ms)
            speed={1000}
          >
            {processedWeeksData.map(weekData => (
              <SwiperSlide
                key={weekData.weekInfo.name + weekData.weekInfo.startDate.toISOString()}
                className="scrollable-slide"
                style={{ height: '100%', overflow: 'auto' }}
              >
                <WeeklyPage
                  userId={userId}
                  weekData={weekData}
                  quotasExist={userSelectedQuotas.length > 0}
                  onAddProduction={openProductModal}
                  onEditEntry={handleOpenEditModal}
                />
              </SwiperSlide>
            ))}
          </Swiper>
        ) : (
          PagerView && (
            <Suspense fallback={<ActivityIndicator size="large" color={theme.colors.primary} />}>
              <PagerView
                style={styles.pagerView}
                initialPage={currentPageIndex}
                onPageSelected={e => setCurrentPageIndex(e.nativeEvent.position)}
                key={pagerKey}
              >
                {processedWeeksData.map((weekData, index) => (
                  <View key={index} style={styles.fullFlex}>
                    <ScrollView showsVerticalScrollIndicator={false}>
                      <WeeklyPage
                        userId={userId}
                        weekData={weekData}
                        quotasExist={userSelectedQuotas.length > 0}
                        onAddProduction={openProductModal}
                        onEditEntry={handleOpenEditModal}
                      />
                    </ScrollView>
                  </View>
                ))}
              </PagerView>
            </Suspense>
          )
        ))}
      <SelectProductModal
        visible={isProductModalVisible}
        onClose={() => setIsProductModalVisible(false)}
        userSelectedQuotas={userSelectedQuotas}
        onSelectProduct={handleSelectProduct}
        selectedDate={selectedDateForInput}
      />
      <EditEntryModal
        visible={isEditModalVisible}
        onClose={handleCloseEditModal}
        entry={editingEntry}
        onUpdate={handleUpdateEntry}
        onDelete={handleDeleteEntry}
        isSaving={isSaving}
      />
      <AlertModal
        visible={isCustomAlertVisible}
        message={customAlertMessage}
        buttons={customAlertButtons}
        onClose={closeAlert}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background1 },
  pagerView: { flex: 1, width: '100%' },
  fullFlex: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: theme.spacing['level-6'] },
  emptyText: {
    fontSize: theme.typography.fontSize['level-4'],
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginBottom: theme.spacing['level-2'],
  },
});
