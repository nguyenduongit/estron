// src/stores/productionStore.ts
import { create } from 'zustand';
import { supabase } from '../services/supabase';
import { RealtimePostgresChangesPayload, RealtimeChannel } from '@supabase/supabase-js';
import {
  Profile,
  UserSelectedQuota,
  QuotaSetting,
  DailyProductionData,
  DailySupplementaryData,
  ProductionEntry,
} from '../types/data';
import {
  getUserProfile,
  getUserSelectedQuotas,
  getProductionEntriesByDateRange,
  getSupplementaryDataByDateRange,
  getQuotaSettingsByProductCodes,
  getQuotaValueBySalaryLevel
} from '../services/storage';
import {
  getCurrentEstronWeekInfo,
  formatToYYYYMMDD,
  getDayOfWeekVietnamese,
  formatDate,
  getToday,
  addDays,
} from '../utils/dateUtils';
import { ProcessedWeekData } from '../screens/InputTab/ProductScreen';

interface ProductState {
  userProfile: Profile | null;
  userSelectedQuotas: UserSelectedQuota[];
  quotaSettingsMap: Map<string, QuotaSetting>;
  processedWeeksData: ProcessedWeekData[];
  estronWeekInfo: ReturnType<typeof getCurrentEstronWeekInfo> | null;
  targetDate: Date;
  isLoading: boolean;
  error: string | null;
  isViewingPreviousMonth: boolean;
  subscriptions: RealtimeChannel[];
  // *** THAY ĐỔI 1: Thêm state cho trang hiện tại ***
  currentPageIndex: number; 
}

interface ProductActions {
  setTargetDate: (date: Date) => void;
  setCurrentPageIndex: (index: number) => void; // Thêm action mới
  loadInitialData: (userId: string, dateForData: Date) => Promise<void>;
  handleRealtimeUpdate: (payload: RealtimePostgresChangesPayload<{ [key: string]: any }>) => void;
  initialize: (userId: string) => void;
  cleanup: () => void;
}

export const useProductionStore = create<ProductState & ProductActions>((set, get) => ({
  userProfile: null,
  userSelectedQuotas: [],
  quotaSettingsMap: new Map(),
  processedWeeksData: [],
  estronWeekInfo: null,
  targetDate: getToday(),
  isLoading: true,
  error: null,
  isViewingPreviousMonth: false,
  subscriptions: [],
  // *** THAY ĐỔI 2: Khởi tạo giá trị ban đầu ***
  currentPageIndex: 0, 

  // Actions
  setCurrentPageIndex: (index) => set({ currentPageIndex: index }),

  setTargetDate: (date) => {
    const today = getToday();
    // So sánh ngày tháng năm để xác định có đang xem tháng cũ không
    const isViewingPrev = date.getDate() !== today.getDate() || date.getMonth() !== today.getMonth() || date.getFullYear() !== today.getFullYear();
    set({ targetDate: date, isViewingPreviousMonth: isViewingPrev });
    const userId = get().userProfile?.id;
    if (userId) {
      get().loadInitialData(userId, date);
    }
  },

  loadInitialData: async (userId, dateForData) => {
    set({ isLoading: true, error: null });
    try {
        const today = getToday();
        const currentEstronInfo = getCurrentEstronWeekInfo(dateForData);
        // ... (logic lấy dữ liệu không đổi)
        const { startDate, endDate } = currentEstronInfo.estronMonth;
        const [profileRes, quotasRes, productionRes, supplementaryRes] = await Promise.all([
            getUserProfile(userId),
            getUserSelectedQuotas(userId),
            getProductionEntriesByDateRange(userId, formatToYYYYMMDD(startDate), formatToYYYYMMDD(endDate)),
            getSupplementaryDataByDateRange(userId, formatToYYYYMMDD(startDate), formatToYYYYMMDD(endDate))
        ]);
        if (profileRes.error || quotasRes.error || productionRes.error || supplementaryRes.error) {
            throw new Error(profileRes.error?.message || quotasRes.error?.message || productionRes.error?.message || supplementaryRes.error?.message || 'Lỗi không xác định');
        }
        const profileData = profileRes.data;
        const selectedQuotasData = quotasRes.data || [];
        const productionEntriesFromSupabase = productionRes.data || [];
        const supplementaryDataForMonth = supplementaryRes.data || [];
        const supplementaryDataMap = new Map<string, DailySupplementaryData>();
        supplementaryDataForMonth.forEach(data => { if (data.date) supplementaryDataMap.set(data.date, data); });
        const allQuotaSettingsNeededCodes = selectedQuotasData.map(usq => usq.product_code);
        const newQuotaSettingsMap = new Map<string, QuotaSetting>();
        if (allQuotaSettingsNeededCodes.length > 0) {
            const { data: settingsResults, error: settingsError } = await getQuotaSettingsByProductCodes(allQuotaSettingsNeededCodes);
            if (settingsError) throw settingsError;
            (settingsResults || []).forEach(qs => newQuotaSettingsMap.set(qs.product_code, qs));
        }
        const weeksToProcess = currentEstronInfo.allWeeksInMonth;
        const isViewingPreviousMonth = get().isViewingPreviousMonth;
        const weeksData: ProcessedWeekData[] = weeksToProcess.map(week => {
            let totalWeeklyWorkAcc = 0;
            const daysInWeekToDisplay = isViewingPreviousMonth ? week.days : week.days.filter(dayDate => new Date(dayDate) <= today);
            const dailyDataForWeek: DailyProductionData[] = daysInWeekToDisplay.map(dayDate => {
                const yyyymmdd = formatToYYYYMMDD(dayDate);
                const entriesForDay = productionEntriesFromSupabase.filter(entry => entry.date === yyyymmdd);
                const suppDataForDay = supplementaryDataMap.get(yyyymmdd);
                let totalDailyWork = 0;
                const dailyEntries = entriesForDay.map(entry => {
                    const quotaSetting = newQuotaSettingsMap.get(entry.product_code);
                    let workAmount = 0;
                    if (quotaSetting && profileData?.salary_level && entry.quantity != null) {
                        const dailyQuota = getQuotaValueBySalaryLevel(quotaSetting, profileData.salary_level);
                        if (dailyQuota > 0) workAmount = entry.quantity / dailyQuota;
                    }
                    totalDailyWork += workAmount;
                    return { id: entry.id, stageCode: entry.product_code, quantity: entry.quantity || 0, workAmount: parseFloat(workAmount.toFixed(2)), po: entry.po, box: entry.box, batch: entry.batch, verified: entry.verified };
                });
                totalWeeklyWorkAcc += totalDailyWork;
                return { date: yyyymmdd, dayOfWeek: getDayOfWeekVietnamese(dayDate), formattedDate: formatDate(dayDate, 'dd/MM'), entries: dailyEntries, totalWorkForDay: parseFloat(totalDailyWork.toFixed(2)), supplementaryData: suppDataForDay };
            });
            return { weekInfo: week, dailyData: dailyDataForWeek, totalWeeklyWork: parseFloat(totalWeeklyWorkAcc.toFixed(2)) };
        }).filter(weekData => weekData.dailyData.length > 0);

        // *** THAY ĐỔI 3: Thêm logic tính toán trang ban đầu ***
        let initialPageIndex = 0;
        if (weeksData.length > 0) {
          if (isViewingPreviousMonth) {
            initialPageIndex = weeksData.length - 1;
          } else if (currentEstronInfo.currentWeek) {
            const todayWeekIndex = weeksData.findIndex(
              w => w.weekInfo.name === currentEstronInfo.currentWeek!.name &&
                   w.weekInfo.startDate.getTime() === currentEstronInfo.currentWeek!.startDate.getTime()
            );
            initialPageIndex = todayWeekIndex !== -1 ? todayWeekIndex : weeksData.length - 1;
          } else {
            initialPageIndex = weeksData.length - 1;
          }
        }
        
        set({
            userProfile: profileData,
            userSelectedQuotas: selectedQuotasData,
            quotaSettingsMap: newQuotaSettingsMap,
            estronWeekInfo: currentEstronInfo,
            processedWeeksData: weeksData,
            isLoading: false,
            currentPageIndex: initialPageIndex, // Set trang ban đầu
        });

    } catch (error: any) {
        set({ error: error.message, isLoading: false });
    }
  },

  // ... (Các hàm handleRealtimeUpdate, initialize, cleanup không đổi)
  handleRealtimeUpdate: (payload) => {
    const { userProfile, quotaSettingsMap, loadInitialData, targetDate } = get();
    if (!userProfile?.salary_level || !userProfile.id || quotaSettingsMap.size === 0) {
      console.warn("Realtime update skipped: profile or quotas not ready. Falling back to full reload.");
      if (userProfile) { loadInitialData(userProfile.id, targetDate); }
      return;
    }
    const record = (payload.new || payload.old) as { date: string; [key: string]: any };
    if (!record || !record.date) return;
    set(state => {
      const newWeeksData = JSON.parse(JSON.stringify(state.processedWeeksData));
      let targetDay: DailyProductionData | null = null;
      let targetWeek: ProcessedWeekData | null = null;
      for (const week of newWeeksData) {
        const dayIndex = week.dailyData.findIndex((d: DailyProductionData) => d.date === record.date);
        if (dayIndex !== -1) { targetWeek = week; targetDay = week.dailyData[dayIndex]; break; }
      }
      if (!targetDay || !targetWeek) {
        console.log("Realtime update for a day not in current view, doing full reload.");
        loadInitialData(userProfile.id, state.targetDate);
        return state;
      }
      const oldTotalDailyWork = targetDay.totalWorkForDay || 0;
      if (payload.table === 'entries') {
        const entryRecord = record as ProductionEntry;
        targetDay.entries = targetDay.entries.filter((e: any) => e.id !== entryRecord.id);
        if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
          const newEntry = payload.new as ProductionEntry;
          const quotaSetting = quotaSettingsMap.get(newEntry.product_code);
          let workAmount = 0;
          if (quotaSetting && userProfile.salary_level && newEntry.quantity != null) {
            const dailyQuota = getQuotaValueBySalaryLevel(quotaSetting, userProfile.salary_level);
            if (dailyQuota > 0) workAmount = newEntry.quantity / dailyQuota;
          }
          targetDay.entries.push({ id: newEntry.id, stageCode: newEntry.product_code, quantity: newEntry.quantity || 0, workAmount: parseFloat(workAmount.toFixed(2)), po: newEntry.po, box: newEntry.box, batch: newEntry.batch, verified: newEntry.verified });
        }
        const newTotalDailyWork = targetDay.entries.reduce((sum: number, e: any) => sum + (e.workAmount || 0), 0);
        targetDay.totalWorkForDay = parseFloat(newTotalDailyWork.toFixed(2));
        targetWeek.totalWeeklyWork = parseFloat((targetWeek.totalWeeklyWork - oldTotalDailyWork + newTotalDailyWork).toFixed(2));
      } else if (payload.table === 'additional') {
        if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
          const newSuppData = payload.new;
          targetDay.supplementaryData = { date: newSuppData.date, leaveHours: newSuppData.leave, overtimeHours: newSuppData.overtime, meetingMinutes: newSuppData.meeting, leaveVerified: newSuppData.leave_verified, overtimeVerified: newSuppData.overtime_verified, meetingVerified: newSuppData.meeting_verified };
        } else if (payload.eventType === 'DELETE') {
          targetDay.supplementaryData = null;
        }
      }
      return { processedWeeksData: newWeeksData };
    });
  },
  initialize: (userId) => {
    get().cleanup();
    get().loadInitialData(userId, get().targetDate);
    const entriesChannel = supabase.channel(`rt-entries-user-${userId}`).on('postgres_changes', { event: '*', schema: 'public', table: 'entries', filter: `user_id=eq.${userId}`}, get().handleRealtimeUpdate).subscribe();
    const additionalChannel = supabase.channel(`rt-additional-user-${userId}`).on('postgres_changes', { event: '*', schema: 'public', table: 'additional', filter: `user_id=eq.${userId}`}, get().handleRealtimeUpdate).subscribe();
    set({ subscriptions: [entriesChannel, additionalChannel] });
  },
  cleanup: () => {
    get().subscriptions.forEach(sub => supabase.removeChannel(sub));
    set({ subscriptions: [] });
  },
}));