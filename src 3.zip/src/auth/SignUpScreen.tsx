// src/auth/SignUpScreen.tsx
import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Alert,
  Text,
  TextInput, 
  TouchableOpacity,
  Platform, 
} from 'react-native';
import { supabase } from '../services/supabase'; //
import { useNavigation } from '@react-navigation/native'; //
import { NativeStackNavigationProp } from '@react-navigation/native-stack'; //
import { AuthStackParamList } from '../navigation/types'; //
import { theme } from '../theme'; //
import CustomButton from './components/CustomButton'; //

type SignUpScreenNavigationProp = NativeStackNavigationProp<
  AuthStackParamList,
  'SignUp'
>;

export default function SignUpScreen() {
  const navigation = useNavigation<SignUpScreenNavigationProp>();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [fullname, setFullname] = useState('');
  const [salaryLevel, setSalaryLevel] = useState('');

  const [loading, setLoading] = useState(false); //
  const [secureTextEntryPassword, setSecureTextEntryPassword] = useState(true); //
  const [secureTextEntryConfirm, setSecureTextEntryConfirm] = useState(true); //

  const handleSignUp = async () => {
    if (!email || !password || !username || !fullname || !confirmPassword || !salaryLevel.trim()) {
      Alert.alert('Lỗi', 'Vui lòng điền đầy đủ thông tin!'); //
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('Lỗi', 'Mật khẩu xác nhận không khớp.'); //
      return;
    }
    if (password.length < 6) {
      Alert.alert('Lỗi', 'Mật khẩu phải có ít nhất 6 ký tự.'); //
      return;
    }

    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email: email,
      password: password,
      options: {
        data: {
          username: username.trim(),
          fullname: fullname.trim(),
          salary_level: salaryLevel.trim(),
        },
      },
    }); //
    setLoading(false);

    if (error) {
      Alert.alert('Lỗi đăng ký', error.message); //
    } else if (data.user && data.session) {
      Alert.alert('Thành công', 'Đăng ký tài khoản thành công!'); //
    } else if (data.user && !data.session) {
      Alert.alert(
        'Xác thực Email',
        'Đăng ký thành công! Vui lòng kiểm tra email để xác thực tài khoản trước khi đăng nhập.' //
      );
      navigation.navigate('SignIn'); //
    } else {
      Alert.alert('Thông báo', 'Có lỗi xảy ra hoặc phản hồi không như mong đợi.'); //
    }
  };

  const renderInput = (
    label: string,
    value: string,
    onChangeText: (text: string) => void,
    placeholder: string,
    options?: {
      secureTextEntry?: boolean;
      autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
      keyboardType?: 'default' | 'email-address' | 'numeric' | 'phone-pad';
    }
  ) => (
    <View style={styles.inputWrapper}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={[styles.input, Platform.OS === 'web' && ({outline: 'none'} as any)]}
        placeholder={placeholder}
        value={value}
        onChangeText={onChangeText}
        secureTextEntry={options?.secureTextEntry}
        autoCapitalize={options?.autoCapitalize || 'sentences'}
        keyboardType={options?.keyboardType || 'default'}
        placeholderTextColor={theme.colors.textSecondary} //
      />
    </View>
  );

  const renderPasswordInput = (
    label: string,
    value: string,
    onChangeText: (text: string) => void,
    placeholder: string,
    secureState: boolean,
    toggleSecureState: () => void
  ) => (
    <View style={styles.inputWrapper}>
      <Text style={styles.label}>{label}</Text>
      <View style={[styles.passwordContainerWeb, Platform.OS === 'web' && ({outline: 'none'} as any)]}>
        <TextInput
          style={[styles.inputPasswordWeb, Platform.OS === 'web' && ({outline: 'none'} as any)]}
          placeholder={placeholder}
          value={value}
          onChangeText={onChangeText}
          secureTextEntry={secureState}
          placeholderTextColor={theme.colors.textSecondary}
        />
        <TouchableOpacity onPress={toggleSecureState} style={styles.eyeButtonWeb}>
          <Text style={styles.eyeButtonText}>{secureState ? 'Hiện' : 'Ẩn'}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );


  // Vì chỉ dành cho web, chúng ta không cần ScrollView và TouchableWithoutFeedback ở đây
  return (
    <View style={styles.webContainer}> {/* Sử dụng webContainer để canh giữa và giới hạn chiều rộng */}
      <View style={styles.headerContainer}>
        <Text style={styles.title}>Tạo tài khoản</Text>
        <Text style={styles.subtitle}>Bắt đầu với Estron</Text>
      </View>

      <View style={styles.formContainer}>
        {renderInput("Họ và Tên", fullname, setFullname, "Nhập họ và tên", { autoCapitalize: 'words' })}
        {renderInput("Email", email, setEmail, "Nhập email của bạn", { keyboardType: 'email-address', autoCapitalize: 'none' })}
        {renderInput("Mã nhân viên", username, setUsername, "Nhập mã nhân viên (ví dụ: p713)", { autoCapitalize: 'none' })}
        {renderInput("Bậc lương", salaryLevel, setSalaryLevel, "Nhập bậc lương của bạn (ví dụ: 2.0)", { keyboardType: 'numeric' })}
        {renderPasswordInput("Mật khẩu", password, setPassword, "Nhập mật khẩu (ít nhất 6 ký tự)", secureTextEntryPassword, () => setSecureTextEntryPassword(!secureTextEntryPassword))}
        {renderPasswordInput("Xác nhận Mật khẩu", confirmPassword, setConfirmPassword, "Nhập lại mật khẩu", secureTextEntryConfirm, () => setSecureTextEntryConfirm(!secureTextEntryConfirm))}

        <CustomButton
            title={loading ? "Đang xử lý..." : "Đăng ký"}
            onPress={handleSignUp}
            loading={loading}
            disabled={loading}
            variant="primary"
            buttonStyle={{ marginTop: theme.spacing.lg }}
        />
      </View>

      <TouchableOpacity
        style={styles.signInLinkButton}
        onPress={() => navigation.navigate('SignIn')}
      >
        <Text style={styles.signInLinkText}>Đã có tài khoản? Đăng nhập</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  webContainer: { // Style cho container chính trên web
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.lg, //
    backgroundColor: theme.colors.background, //
    width: '100%',
    marginHorizontal: 'auto', // Canh giữa
  },
  // Bỏ scrollContainer vì không dùng ScrollView cho web
  // container: { ... } // Style này có thể không cần thiết hoặc được gộp vào webContainer
  headerContainer: {
    alignItems: 'center',
    marginBottom: theme.spacing.lg, // Giảm bớt so với xl
  },
  title: {
    ...theme.typography.h1, //
    color: theme.colors.primary, // Đổi màu cho nhất quán
  },
  subtitle: {
    ...theme.typography.body, //
    color: theme.colors.textSecondary, //
    marginTop: theme.spacing.sm, //
  },
  formContainer: {
    width: '100%', //
  },
  inputWrapper: { // Wrapper cho label và input
    width: '100%',
    marginBottom: theme.spacing.md, //
  },
  label: {
    ...theme.typography.bodySmall, //
    color: theme.colors.textSecondary, //
    marginBottom: theme.spacing.xs, //
  },
  input: { // Style chung cho TextInput
    height: 48,
    backgroundColor: theme.colors.cardBackground, //
    borderWidth: 1,
    borderColor: theme.colors.borderColor, //
    borderRadius: theme.spacing.sm, //
    paddingHorizontal: theme.spacing.md, //
    ...theme.typography.body, //
    color: theme.colors.text, //
    width: '100%',
  },
  passwordContainerWeb: { // Container cho input mật khẩu và nút Hiện/Ẩn trên web
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.cardBackground, //
    borderWidth: 1,
    borderColor: theme.colors.borderColor, //
    borderRadius: theme.spacing.sm, //
    width: '100%',
  },
  inputPasswordWeb: { // TextInput cho mật khẩu trên web
    flex: 1,
    height: 48,
    paddingHorizontal: theme.spacing.md, //
    ...theme.typography.body, //
    color: theme.colors.text, //
    borderWidth: 0, // Bỏ border riêng của input vì container đã có
  },
  eyeButtonWeb: { // Nút Hiện/Ẩn mật khẩu trên web
    padding: theme.spacing.md, //
  },
  eyeButtonText: { // Style cho chữ Hiện/Ẩn
    ...theme.typography.caption, //
    color: theme.colors.primary, //
  },
  // Loại bỏ button, signUpButton, buttonText, buttonDisabled vì đã dùng CustomButton
  signInLinkButton: {
    marginTop: theme.spacing.lg, //
    alignItems: 'center', //
  },
  signInLinkText: {
    ...theme.typography.bodySmall, //
    color: theme.colors.primary, //
  },
});