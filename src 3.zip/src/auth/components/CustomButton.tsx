// src/components/CustomButton.tsx
import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, ViewStyle, TextStyle, TouchableOpacityProps } from 'react-native';
import { theme } from '../../theme'; // Đảm bảo đường dẫn đúng

interface CustomButtonProps extends TouchableOpacityProps {
  title: string;
  loading?: boolean;
  buttonStyle?: ViewStyle;
  textStyle?: TextStyle;
  variant?: 'primary' | 'outline'; // Thêm variant 'outline' như nút "Create an account"
}

const CustomButton: React.FC<CustomButtonProps> = ({
  title,
  onPress,
  loading,
  disabled,
  buttonStyle,
  textStyle,
  variant = 'primary',
  ...touchableOpacityProps
}) => {
  const isPrimary = variant === 'primary';

  return (
    <TouchableOpacity
      style={[
        styles.buttonBase,
        isPrimary ? styles.primaryButton : styles.outlineButton,
        disabled || loading ? styles.disabled : {},
        buttonStyle,
      ]}
      onPress={onPress}
      disabled={disabled || loading}
      {...touchableOpacityProps}
    >
      {loading ? (
        <ActivityIndicator color={isPrimary ? theme.colors.white : theme.colors.primary} />
      ) : (
        <Text style={[
          styles.textBase,
          isPrimary ? styles.primaryText : styles.outlineText,
          textStyle
        ]}>
          {title}
        </Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  buttonBase: {
    width: '100%',
    paddingVertical: theme.spacing.md - theme.spacing.xs / 2, // Khoảng 14dp, tùy chỉnh
    borderRadius: theme.spacing.sm, // Bo góc button (8dp)
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48, // Chiều cao cố định cho button như trong ảnh
    marginBottom: theme.spacing.md,
  },
  primaryButton: {
    backgroundColor: theme.colors.primary,
  },
  outlineButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: theme.colors.primary,
  },
  textBase: {
    ...theme.typography.bodySmall, // Hoặc titleMedium tùy theo độ lớn chữ mong muốn
    fontWeight: 'bold', // Chữ trong button thường đậm hơn
  },
  primaryText: {
    color: theme.colors.white,
  },
  outlineText: {
    color: theme.colors.primary,
  },
  disabled: {
    opacity: 0.6,
  },
});

export default CustomButton;