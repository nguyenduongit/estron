// components/common/ModalWrapper.tsx
import React, { useState, useEffect } from "react";
import { Modal, View, StyleSheet, TouchableWithoutFeedback, Text, TouchableOpacity, Platform, Dimensions, ViewStyle } from "react-native";
import { theme } from "../../theme"; //
import Ionicons from "@expo/vector-icons/Ionicons";

interface ModalWrapperProps {
  visible: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
}

const ORIGINAL_MAX_WIDTH = 400;

const ModalWrapper: React.FC<ModalWrapperProps> = ({ visible, onClose, children, title }) => {
  const [dynamicMaxWidth, setDynamicMaxWidth] = useState(ORIGINAL_MAX_WIDTH);
  // State mới cho style của overlay
  const [dynamicOverlayStyle, setDynamicOverlayStyle] = useState<ViewStyle>(() => styles.overlayBase);

  useEffect(() => {
    const updateModalStyles = () => {
      const screenWidth = Dimensions.get('window').width;
      const screenHeight = Dimensions.get('window').height;

      if (Platform.OS === 'web') {
        const appVisibleWidth = screenHeight / 2; // Chiều rộng ảo của app trên web
        
        const calculatedModalContentMaxWidth = Math.min(appVisibleWidth * 0.90, ORIGINAL_MAX_WIDTH); // Nội dung modal chiếm 90% appVisibleWidth, không quá 400px
        setDynamicMaxWidth(calculatedModalContentMaxWidth < 100 ? appVisibleWidth * 0.9 : calculatedModalContentMaxWidth);

        // Cập nhật style cho overlay trên web
        setDynamicOverlayStyle({
          ...styles.overlayBase,
          width: appVisibleWidth,     // Overlay sẽ có chiều rộng bằng appVisibleWidth
          marginHorizontal: 'auto', // Để tự động căn giữa overlay này trên trang (nếu Modal root cho phép)
                                    // Giả định Modal root của React Native vẫn là fullscreen,
                                    // chúng ta đang style cho View con trực tiếp của nó.
          // Nếu muốn overlay không full height mà chỉ bằng app window height:
          // height: screenHeight, // Hoặc giá trị cụ thể nếu app không full height trình duyệt
        });

      } else {
        // Đối với native
        setDynamicMaxWidth(Math.min(screenWidth * 0.9, ORIGINAL_MAX_WIDTH));
        setDynamicOverlayStyle(styles.overlayBase); // Reset về style cơ sở cho native
      }
    };

    updateModalStyles();
    const subscription = Dimensions.addEventListener('change', updateModalStyles);
    return () => {
      subscription?.remove();
    };
  }, []);

  const modalContentStyle: ViewStyle = {
    ...styles.modalContentBase,
    maxWidth: dynamicMaxWidth,
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}
    >
      {/* TouchableWithoutFeedback này và View bên trong nó chính là overlay */}
      <TouchableWithoutFeedback onPress={onClose} accessible={false}>
        {/* View này hoạt động như một container cho overlay và modal content.
          Trên web, nếu React Native Modal render một div fullscreen, 
          thì việc style View này sẽ cố gắng giới hạn vùng tương tác và làm mờ.
        */}
        <View style={styles.modalRootContainerWeb}> 
          <View style={dynamicOverlayStyle}>
            <TouchableWithoutFeedback>
              {/* View này là modalContent thực sự, không nên có onPress ở đây */}
              <View style={modalContentStyle}>
                {title && (
                  <View style={styles.header}>
                    <Text style={styles.title}>{title}</Text>
                    <TouchableOpacity onPress={onClose} style={styles.closeButton}>
                      <Ionicons name="close-circle" size={28} color={theme.colors.secondary} />
                    </TouchableOpacity>
                  </View>
                )}
                {children}
              </View>
            </TouchableWithoutFeedback>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  // Style mới cho container gốc của Modal trên web, giúp căn giữa overlay đã thu nhỏ
  modalRootContainerWeb: {
    flex: 1,
    justifyContent: 'center', // Căn giữa dynamicOverlayStyle theo chiều dọc
    alignItems: 'center',   // Căn giữa dynamicOverlayStyle theo chiều ngang (nếu dynamicOverlayStyle không có marginHorizontal: 'auto')
                            // Nếu dynamicOverlayStyle đã có marginHorizontal: 'auto', alignItems ở đây có thể không cần thiết cho chiều ngang.
    // backgroundColor: 'transparent', // Đảm bảo không có màu nền ngoài ý muốn ở đây
  },
  overlayBase: { // Style cơ sở cho overlay
    // flex: 1, // Bỏ flex: 1 nếu width/height được đặt cụ thể và không muốn nó chiếm hết không gian của modalRootContainerWeb
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
    // width và marginHorizontal sẽ được thêm động cho web
    // Đối với native, nó sẽ hoạt động như cũ (fullscreen overlay)
    // Nếu đặt width/height cụ thể cho web, cần đảm bảo justifyContent/alignItems vẫn căn giữa modalContent
    // một cách chính xác bên trong overlay đã thu nhỏ.
    // Có thể cần set height cụ thể cho overlay trên web nếu muốn nó không full height.
    height: Platform.OS === 'web' ? '100%' : undefined, // Overlay trên web vẫn cao 100% của width đã set (appVisibleWidth) hoặc 100% của viewport nếu width không được set.
                                                        // Trên native, height không cần thiết vì flex:1
    width: Platform.OS === 'web' ? undefined : '100%',   // Trên native, width 100% để flex:1 hoạt động cho height
                                                        // Trên web, width sẽ được set bởi dynamicOverlayStyle
    padding: Platform.OS === 'web' ? 0 : undefined, // Reset padding trên web cho overlay nếu có
  },
  modalContentBase: {
    width: "90%", // Nội dung modal sẽ chiếm 90% chiều rộng của overlay (đã được thu nhỏ trên web)
                  // hoặc 90% của chính nó nếu overlay không có width cụ thể.
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    ...theme.shadow.lg,
    // maxWidth được đặt động
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.lightGrey,
    paddingBottom: theme.spacing.sm,
  },
  title: {
    fontSize: theme.typography.h3.fontSize,
    fontWeight: theme.typography.h3.fontWeight,
    color: theme.colors.text,
  },
  closeButton: {
    padding: theme.spacing.xs,
  },
});

export default ModalWrapper;