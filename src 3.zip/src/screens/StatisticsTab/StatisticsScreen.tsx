// src/screens/StatisticsTab/StatisticsScreen.tsx
import React, { useState, useLayoutEffect, useCallback, useMemo } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, ScrollView, Dimensions, TouchableOpacity, Platform, Linking, Alert, LayoutChangeEvent } from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import type { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import Ionicons from '@expo/vector-icons/Ionicons';
import { PieChart } from "react-native-gifted-charts";
import * as Clipboard from 'expo-clipboard';

import { BottomTabNavigatorParamList } from '../../navigation/types';
import { theme } from '../../theme';
import { EstronMonthPeriod } from '../../utils/dateUtils';
import {
  getToday,
  getEstronMonthPeriod,
  calculateStandardWorkdays,
  formatToYYYYMMDD,
} from '../../utils/dateUtils';
import {
  getQuotasFromStorage,
  getProductionEntriesByDateRangeFromStorage,
  getSupplementaryDataByDateRangeFromStorage,
} from '../../services/storage';
import Button from '../../components/common/Button';
import ModalWrapper from '../../components/common/ModalWrapper';

type StatisticsScreenNavigationProp = BottomTabNavigationProp<BottomTabNavigatorParamList, 'StatisticsTab'>;

const AUTHOR_NAME = "Nguyễn Quốc Dương";
const DONATE_INFO = {
  bank: "Ngân hàng Vietcombank",
  accountNumber: "0421000518940",
  accountHolder: "NGUYEN QUOC DUONG"
};

export default function StatisticsScreen() {
  const navigation = useNavigation<StatisticsScreenNavigationProp>();

  const [isLoading, setIsLoading] = useState(true);
  const [currentEstronMonth, setCurrentEstronMonth] = useState<EstronMonthPeriod | null>(null);
  const [errorLoading, setErrorLoading] = useState<string | null>(null);

  const [standardWorkdaysForMonth, setStandardWorkdaysForMonth] = useState<number>(0);
  const [standardWorkdaysToCurrent, setStandardWorkdaysToCurrent] = useState<number>(0);
  const [totalProductWorkDone, setTotalProductWorkDone] = useState<number>(0);
  const [targetProductWork, setTargetProductWork] = useState<number>(0);
  const [totalOvertimeHours, setTotalOvertimeHours] = useState<number>(0);
  const [totalLeaveDays, setTotalLeaveDays] = useState<number>(0);
  const [totalMeetingHours, setTotalMeetingHours] = useState<number>(0);
  const [isAuthorModalVisible, setIsAuthorModalVisible] = useState(false);

  // Khởi tạo contentWidth dựa trên Platform
  const [contentWidth, setContentWidth] = useState(
    Platform.OS === 'web' ? 0 : Dimensions.get('window').width
  );
  // Thêm một state để thay đổi key của ScrollView, buộc re-mount/re-layout
  const [layoutKey, setLayoutKey] = useState('initialKey');


  const handleShowAuthorModal = useCallback(() => setIsAuthorModalVisible(true), []);
  const handleCloseAuthorModal = useCallback(() => setIsAuthorModalVisible(false), []);

  const copyToClipboard = async (text: string) => {
    await Clipboard.setStringAsync(text);
    Alert.alert("Đã sao chép", `${text} đã được sao chép vào bộ nhớ tạm.`);
  };

  useLayoutEffect(() => {
    navigation.setOptions({
      title: currentEstronMonth?.estronMonth
        ? `Thống kê tháng ${currentEstronMonth.estronMonth}`
        : 'Thống Kê Chung',
      headerRight: () => (
        <TouchableOpacity
          onPress={handleShowAuthorModal}
          style={{
            marginRight : Platform.OS === 'ios' ? theme.spacing.md : theme.spacing.md,
            padding: theme.spacing.xs,
          }}
        >
          <Ionicons name="information-circle-outline" size={26} color={theme.colors.white} />
        </TouchableOpacity>
      ),
    });
  }, [navigation, currentEstronMonth, handleShowAuthorModal]);

  const loadStatisticsData = useCallback(async () => {
    // setIsLoading(true); // Đã set ở useFocusEffect
    // setErrorLoading(null); // Đã set ở useFocusEffect
    // ... (Nội dung hàm load data giữ nguyên như trước) ...
    try {
      const today = getToday();
      const monthInfo = getEstronMonthPeriod(today);
      setCurrentEstronMonth(monthInfo);

      if (monthInfo && monthInfo.startDate && monthInfo.endDate) {
        const startDateStr = formatToYYYYMMDD(monthInfo.startDate);
        const endDateStr = formatToYYYYMMDD(monthInfo.endDate);

        const workdaysForMonth = calculateStandardWorkdays(monthInfo.startDate, monthInfo.endDate);
        setStandardWorkdaysForMonth(workdaysForMonth);

        const cappedToday = today > monthInfo.endDate ? monthInfo.endDate : today;
        const workdaysToCurrent = calculateStandardWorkdays(monthInfo.startDate, cappedToday);
        setStandardWorkdaysToCurrent(workdaysToCurrent);

        const [quotas, productionEntries, supplementaryData] = await Promise.all([
          getQuotasFromStorage(),
          getProductionEntriesByDateRangeFromStorage(startDateStr, endDateStr),
          getSupplementaryDataByDateRangeFromStorage(startDateStr, endDateStr),
        ]);

        let calculatedTotalProductWorkDone = 0;
        if (quotas.length > 0 && productionEntries.length > 0) {
          productionEntries.forEach(entry => {
            const quota = quotas.find(q => q.stageCode === entry.stageCode);
            if (quota && quota.dailyQuota > 0) {
              calculatedTotalProductWorkDone += entry.quantity / quota.dailyQuota;
            }
          });
        }
        setTotalProductWorkDone(parseFloat(calculatedTotalProductWorkDone.toFixed(2)));

        let currentTotalOvertime = 0;
        let currentTotalLeaveHours = 0;
        let currentTotalMeetingMinutes = 0;

        supplementaryData.forEach(item => {
          if (item.overtimeHours && item.overtimeHours > 0) {
            currentTotalOvertime += item.overtimeHours;
          }
          if (item.leaveHours && item.leaveHours > 0) {
            currentTotalLeaveHours += item.leaveHours;
          }
          if (item.meetingMinutes && item.meetingMinutes > 0) {
            currentTotalMeetingMinutes += item.meetingMinutes;
          }
        });

        const finalTotalOvertimeHours = parseFloat(currentTotalOvertime.toFixed(2));
        const finalTotalLeaveDays = parseFloat((currentTotalLeaveHours / 8).toFixed(2));
        const finalTotalMeetingHours = parseFloat((currentTotalMeetingMinutes / 60).toFixed(2));

        setTotalOvertimeHours(finalTotalOvertimeHours);
        setTotalLeaveDays(finalTotalLeaveDays);
        setTotalMeetingHours(finalTotalMeetingHours);

        const calculatedTargetProductWork = workdaysToCurrent + (finalTotalOvertimeHours / 8) - finalTotalLeaveDays - (finalTotalMeetingHours / 8);
        setTargetProductWork(parseFloat(Math.max(0, calculatedTargetProductWork).toFixed(2)));

      } else {
        setErrorLoading("Không thể xác định thông tin tháng Estron hiện tại.");
        setStandardWorkdaysForMonth(0);
        setStandardWorkdaysToCurrent(0);
        setTotalProductWorkDone(0);
        setTargetProductWork(0);
        setTotalOvertimeHours(0);
        setTotalLeaveDays(0);
        setTotalMeetingHours(0);
      }
    } catch (error) {
      console.error("Error loading statistics data:", error);
      setErrorLoading("Đã có lỗi xảy ra khi tải dữ liệu thống kê.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      setIsLoading(true); // Set loading khi focus
      setErrorLoading(null);
      loadStatisticsData(); // Gọi hàm load data
      if (Platform.OS === 'web') {
        // console.log('Focus effect: Resetting contentWidth to 0 and changing layoutKey');
        setContentWidth(0); // Reset để chờ onLayout
        setLayoutKey(`layoutKey-${Date.now()}`); // Thay đổi key để buộc ScrollView re-mount/re-layout
      } else {
        setContentWidth(Dimensions.get('window').width); // Set cho native
      }
    }, [loadStatisticsData]) // Chỉ phụ thuộc vào loadStatisticsData
  );

  const handleLayout = (event: LayoutChangeEvent) => {
    const { width: newWidth } = event.nativeEvent.layout;
    // console.log(`handleLayout called. newWidth: ${newWidth}, current contentWidth: ${contentWidth}`);
    if (newWidth > 0 && newWidth !== contentWidth) {
      // console.log(`Setting contentWidth from ${contentWidth} to ${newWidth}`);
      setContentWidth(newWidth);
    } else if (newWidth > 0 && contentWidth === 0 && Platform.OS === 'web') {
      // console.log(`Setting contentWidth from 0 to ${newWidth} (initial web layout)`);
      setContentWidth(newWidth); // Quan trọng cho lần đo đầu tiên trên web
    }
  };

  const chartBlockSize = useMemo(() => {
    if (contentWidth < 1) return 0;
    const calculated = (contentWidth - theme.spacing.md * 3) / 2;
    return Math.max(0, calculated); // Đảm bảo không âm
  }, [contentWidth]);

  const smallBlockSize = useMemo(() => {
    if (contentWidth < 1) return 0;
    const calculated = (contentWidth - theme.spacing.md * 4) / 3;
    return Math.max(0, calculated); // Đảm bảo không âm
  }, [contentWidth]);

  const renderProgressChart = useCallback((
    value: number,
    maxValue: number,
    title: string,
    defaultColor: string,
    unit: string = "",
    isProductWorkChart: boolean = false
  ) => {
    // ... (Nội dung hàm giữ nguyên như trước, sử dụng chartBlockSize từ useMemo)
    const percentage = maxValue > 0 ? Math.min(100, Math.max(0, (value / maxValue) * 100)) : (value > 0 ? 100 : 0);
    const displayValue = value >= 0 ? value : 0;

    let ringColor = defaultColor;
    if (isProductWorkChart) {
      ringColor = value >= maxValue ? theme.colors.success : theme.colors.danger;
    }
    const currentChartBlockSize = Math.max(chartBlockSize, 50);

    return (
      <View style={[styles.chartBlockBase, { width: currentChartBlockSize, height: currentChartBlockSize * 1.1 }]}>
        <PieChart
          donut
          radius={Math.max(currentChartBlockSize / 2.8, 20)}
          innerRadius={Math.max(currentChartBlockSize / 4, 15)}
          data={[{ value: percentage, color: ringColor, focused: true }, { value: 100 - percentage, color: theme.colors.lightGrey }]}
          centerLabelComponent={() => (
            <View style={styles.chartCenterLabel}>
              <Text style={[styles.chartValueTextMain, { fontSize: Math.max(currentChartBlockSize / 5.5, 10) }]}>{`${displayValue.toLocaleString()}`}</Text>
              <Text style={[styles.chartValueTextUnit, { fontSize: Math.max(currentChartBlockSize / 10, 8) }]}>{unit}</Text>
            </View>
          )}
        />
        <Text style={styles.chartTitleText}>{title}</Text>
        <Text style={styles.chartSubText}>{`Mục tiêu: ${maxValue.toLocaleString()}${unit}`}</Text>
      </View>
    );
  }, [chartBlockSize]); // Phụ thuộc vào chartBlockSize

  const renderSmallInfoBlock = useCallback((
    iconName: React.ComponentProps<typeof Ionicons>['name'],
    value: number,
    label: string,
    unit: string,
    iconColor: string
  ) => {
    // ... (Nội dung hàm giữ nguyên như trước, sử dụng smallBlockSize từ useMemo)
     const currentSmallBlockSize = Math.max(smallBlockSize, 40);
    return (
      <View style={[styles.smallBlockBase, { width: currentSmallBlockSize, height: currentSmallBlockSize * 1.1 }]}>
        <Ionicons name={iconName} size={Math.max(currentSmallBlockSize / 3.5, 18)} color={iconColor} style={styles.smallBlockIcon} />
        <Text style={[styles.smallBlockValue, {fontSize: Math.max(currentSmallBlockSize / 5, 10)}]}>{value.toLocaleString()} <Text style={styles.smallBlockUnit}>{unit}</Text></Text>
        <Text style={styles.smallBlockLabel}>{label}</Text>
      </View>
    );
  }, [smallBlockSize]); // Phụ thuộc vào smallBlockSize


  if (isLoading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
        <Text style={styles.loadingText}>Đang tải dữ liệu thống kê...</Text>
      </View>
    );
  }

  if (errorLoading) {
     return (
      <View style={styles.centered}>
        <Ionicons name="warning-outline" size={48} color={theme.colors.danger} />
        <Text style={styles.errorText}>{errorLoading}</Text>
        <Button title="Thử Lại" onPress={() => {
            setIsLoading(true); // Set loading true before calling loadStatisticsData again
            loadStatisticsData();
        }} style={{marginTop: theme.spacing.md}}/>
      </View>
    );
  }

  return (
    <ScrollView
        key={layoutKey} // Sử dụng key ở đây
        style={styles.container}
        contentContainerStyle={styles.contentContainer}
        onLayout={handleLayout}
    >
      {/* Luôn render ScrollView, nội dung bên trong sẽ chờ contentWidth */}
      {(Platform.OS === 'web' && contentWidth === 0) ? (
        <View style={styles.centeredFullHeight}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
          <Text style={styles.loadingText}>Đang xác định kích thước...</Text>
        </View>
      ) : (chartBlockSize > 0 && smallBlockSize > 0) ? (
          <>
            <View style={styles.rowContainer}>
                {renderProgressChart(standardWorkdaysToCurrent, standardWorkdaysForMonth, "Ngày công làm việc", theme.colors.success, "ngày")}
                {renderProgressChart(totalProductWorkDone, targetProductWork, "Công sản phẩm", theme.colors.info, "công", true)}
            </View>
            <View style={[styles.rowContainer, { marginTop: theme.spacing.md }]}>
                {renderSmallInfoBlock("time-outline", totalOvertimeHours, "Giờ tăng ca", "", theme.colors.success)}
                {renderSmallInfoBlock("walk-outline", totalLeaveDays, "Ngày nghỉ", "", theme.colors.danger)}
                {renderSmallInfoBlock("people-outline", totalMeetingHours, "Giờ họp/đào tạo", "", theme.colors.warning)}
            </View>
          </>
      ) : (contentWidth > 0) ? ( // Nếu contentWidth > 0 nhưng block sizes <= 0
        <View style={styles.centeredFullHeight}>
            <Text>Kích thước nội dung quá nhỏ để hiển thị.</Text>
            <Text>(Rộng: {contentWidth.toFixed(0)}px)</Text>
        </View>
      ) : null /* Trường hợp khác (ví dụ: native và contentWidth = 0 ban đầu nhưng không phải loading) */
      }

      <ModalWrapper
        visible={isAuthorModalVisible}
        onClose={handleCloseAuthorModal}
      >
        {/* ... (Nội dung Modal không đổi) ... */}
        <View style={styles.authorModalContainer}>
          <View style={styles.authorModalHeader}>
             <Text style={styles.authorModalTitle}>Thông tin tác giả</Text>
             <TouchableOpacity onPress={handleCloseAuthorModal} style={styles.customCloseButton}>
                <Ionicons name="close-circle" size={28} color={theme.colors.secondary} />
             </TouchableOpacity>
          </View>

          <Text style={styles.authorText}>Ứng dụng được phát triển bởi:</Text>
          <Text style={styles.authorName}>{AUTHOR_NAME}</Text>

          <View style={styles.divider} />

          <Text style={styles.donateTitle}>Ủng hộ tác giả:</Text>
          <Text style={styles.donateText}>
            Nếu bạn thấy ứng dụng này hữu ích, bạn có thể ủng hộ một ly cafe cho tác giả qua:
          </Text>
          <View style={styles.donateInfoRow}>
            <Text style={styles.donateBank}>{DONATE_INFO.bank}</Text>
          </View>
           <View style={styles.donateInfoRow}>
            <Text style={styles.donateAccountLabel}>Chủ TK:</Text>
            <Text style={styles.donateAccountValue}>{DONATE_INFO.accountHolder}</Text>
          </View>
          <View style={styles.donateInfoRow}>
            <Text style={styles.donateAccountLabel}>Số TK:</Text>
            <Text style={styles.donateAccountValue}>{DONATE_INFO.accountNumber}</Text>
            <TouchableOpacity onPress={() => copyToClipboard(DONATE_INFO.accountNumber)} style={styles.copyButton}>
              <Ionicons name="copy-outline" size={20} color={theme.colors.primary} />
            </TouchableOpacity>
          </View>
          <Button title="Đóng" onPress={handleCloseAuthorModal} style={styles.closeModalButton} />
        </View>
      </ModalWrapper>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  contentContainer: {
    padding: theme.spacing.md,
    flexGrow: 1, // Quan trọng để centeredFullHeight hoạt động đúng
  },
  centered: { // Dùng cho màn hình loading/error toàn cục
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.lg,
  },
  centeredFullHeight: { // Dùng cho placeholder bên trong ScrollView
    // flex: 1, // Không cần flex:1 ở đây vì ScrollView đã có flexGrow:1 cho contentContainerStyle
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.lg,
    minHeight: 200, // Đảm bảo placeholder có chiều cao tối thiểu
  },
  loadingText: {
    marginTop: theme.spacing.md,
    fontSize: theme.typography.body.fontSize,
    color: theme.colors.textSecondary,
  },
  // ... (các styles khác giữ nguyên như trước) ...
  errorText: {
    marginTop: theme.spacing.md,
    fontSize: theme.typography.body.fontSize,
    color: theme.colors.danger,
    textAlign: 'center',
  },
  rowContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: theme.spacing.md,
  },
  chartBlockBase: {
    backgroundColor: theme.colors.cardBackground,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.sm,
    alignItems: 'center',
    justifyContent: 'space-around', 
    ...theme.shadow.md,
  },
  chartCenterLabel: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  chartValueTextMain: {
    fontWeight: 'bold',
    color: theme.colors.text,
  },
  chartValueTextUnit: {
    color: theme.colors.textSecondary,
    marginTop: -theme.spacing.xs / 2, 
  },
  chartTitleText: {
    fontSize: theme.typography.bodySmall.fontSize * 0.9, 
    fontWeight: '600',
    color: theme.colors.text,
    textAlign: 'center',
    marginTop: theme.spacing.xs,
  },
  chartSubText: {
    fontSize: theme.typography.caption.fontSize * 0.9, 
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
  smallBlockBase: {
    backgroundColor: theme.colors.cardBackground,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.xs, 
    alignItems: 'center',
    justifyContent: 'center',
    ...theme.shadow.sm,
  },
  smallBlockIcon: {
    marginBottom: theme.spacing.xs / 2,
  },
  smallBlockValue: {
    fontWeight: 'bold',
    color: theme.colors.text,
    textAlign: 'center',
  },
  smallBlockUnit: {
    fontSize: theme.typography.caption.fontSize * 0.9, 
    fontWeight: 'normal',
    color: theme.colors.textSecondary,
  },
  smallBlockLabel: {
    fontSize: theme.typography.caption.fontSize * 0.85, 
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginTop: theme.spacing.xs / 2,
  },
  authorModalContainer: {
    alignItems: 'center',
    paddingHorizontal: theme.spacing.sm,
  },
  authorModalHeader: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: theme.spacing.lg,
    paddingBottom: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.borderColor,
    position: 'relative',
  },
  authorModalTitle: {
    fontSize: theme.typography.h3.fontSize,
    fontWeight: theme.typography.h3.fontWeight,
    color: theme.colors.text,
  },
  customCloseButton: {
    position: 'absolute',
    right: -theme.spacing.sm,
    top: -theme.spacing.sm,
    padding: theme.spacing.xs,
  },
  authorText: {
    fontSize: theme.typography.body.fontSize,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.xs,
  },
  authorName: {
    fontSize: theme.typography.h4.fontSize,
    fontWeight: theme.typography.h4.fontWeight,
    color: theme.colors.primary,
    marginBottom: theme.spacing.md,
  },
  divider: {
    height: 1,
    backgroundColor: theme.colors.borderColor,
    width: '80%',
    marginVertical: theme.spacing.md,
  },
  donateTitle: {
    fontSize: theme.typography.h4.fontSize,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },
  donateText: {
    fontSize: theme.typography.bodySmall.fontSize,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginBottom: theme.spacing.sm,
    paddingHorizontal: theme.spacing.sm,
  },
  donateInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: theme.spacing.xs,
  },
  donateBank: {
    fontSize: theme.typography.body.fontSize,
    fontWeight: 'bold',
    color: theme.colors.success,
    marginBottom: theme.spacing.xs,
  },
  donateAccountLabel: {
    fontSize: theme.typography.bodySmall.fontSize,
    color: theme.colors.textSecondary,
    marginRight: theme.spacing.xs,
  },
  donateAccountValue: {
    fontSize: theme.typography.body.fontSize,
    color: theme.colors.text,
    fontWeight: '500',
  },
  copyButton: {
    marginLeft: theme.spacing.md,
    padding: theme.spacing.xs,
  },
  closeModalButton: {
    marginTop: theme.spacing.lg,
    width: '60%',
  }
});