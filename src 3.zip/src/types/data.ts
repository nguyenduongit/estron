// src/types/data.ts
export interface Quota {
  id: string; // UUID, duy nhất cho mỗi định mức
  stageCode: string; // Mã công đoạn (người dùng nhập, nên là duy nhất)
  dailyQuota: number; // Định mức ngày
  order: number; // Để sắp xếp thứ tự hiển thị
}

export interface ProductionEntry {
  id: string; // UUID, duy nhất cho mỗi lần nhập
  date: string; // Định dạng yyyy-MM-DD (khóa chính cùng với stageCode cho một ngày)
  stageCode: string; // Mã công đoạn, tham chiếu đến Quota.stageCode
  quantity: number; // Số lượng sản xuất
}

// Dùng để nhóm các ProductionEntry theo ngày cho việc hiển thị trên Card
export interface DailyProductionData {
  date: string; // yyyy-MM-DD
  dayOfWeek: string; // Thứ trong tuần (ví dụ: "Thứ 2")
  formattedDate: string; // Ngày tháng định dạng (ví dụ: "21/04")
  entries: Array<{
    id: string; // ID của ProductionEntry
    stageCode: string;
    quantity: number;
    workAmount?: number; // Số công = quantity / dailyQuota (của stageCode đó)
  }>;
  totalWorkForDay?: number; // Tổng công của ngày
}

// Interface for supplementary daily data (nghỉ, tăng ca, họp)
export interface DailySupplementaryData {
  date: string; // Primary key: yyyy-MM-DD, duy nhất cho mỗi entry
  leaveHours?: number | null; // Số giờ nghỉ
  overtimeHours?: number | null; // Số giờ tăng ca
  meetingMinutes?: number | null; // Số phút họp/đào tạo
}

// ++ THÊM MỚI CHO SUPABASE ++
export interface QuotaSetting {
  product_code: string; // PK
  product_name: string;
  level_0_9?: number | null;
  level_1_0?: number | null;
  level_1_1?: number | null;
  level_2_0?: number | null;
  level_2_1?: number | null;
  level_2_2?: number | null;
  level_2_5?: number | null;
  // Thêm các level khác nếu có trong bảng quota_settings
  created_at?: string; // Thêm field này nếu có trong bảng của bạn
}

export interface UserSelectedQuota {
  user_id: string; // PK
  product_code: string; // PK
  product_name: string; // Lấy từ QuotaSetting khi thêm
  zindex: number; // Để sắp xếp
  created_at?: string;
}

export interface Profile {
  id: string; // user_id, matches auth.uid()
  email?: string;
  username?: string | null;
  full_name?: string | null;
  avatar_url?: string | null;
  salary_level?: string | null; // Ví dụ: "0.9", "1.0", "2.0", "2.1", "2.2", "2.5"
  role?: string | null; // Ví dụ: "user", "admin"
  is_active?: boolean | null;
  created_at?: string;
  updated_at?: string;
}
// ++ KẾT THÚC THÊM MỚI ++