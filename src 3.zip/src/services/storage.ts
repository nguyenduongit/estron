// src/services/storage.ts
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Quota, ProductionEntry, DailySupplementaryData, UserSelectedQuota, QuotaSetting, Profile } from '../types/data'; //
import 'react-native-get-random-values'; 
import { v4 as uuidv4 } from 'uuid';
import { supabase } from './supabase'; //

const QUOTAS_KEY = 'ESTRON_APP_QUOTAS_V1'; //
const PRODUCTION_ENTRIES_KEY = 'ESTRON_APP_PRODUCTION_ENTRIES_V1'; //
const SUPPLEMENTARY_DATA_KEY = 'ESTRON_APP_SUPPLEMENTARY_DATA_V1'; //

// --- Quota Management (Định mức) AsyncStorage ---
export const getQuotasFromStorage = async (): Promise<Quota[]> => {
  try {
    const jsonValue = await AsyncStorage.getItem(QUOTAS_KEY);
    const quotas = jsonValue != null ? JSON.parse(jsonValue) : []; //
    return quotas.sort((a: Quota, b: Quota) => a.order - b.order); //
  } catch (e) {
    console.error("Lỗi khi tải định mức từ AsyncStorage:", e);
    return [];
  }
};

export const saveQuotasToStorage = async (quotas: Quota[]): Promise<boolean> => {
  try {
    const sortedAndOrderedQuotas = quotas.map((q, index) => ({ ...q, order: index })); //
    const jsonValue = JSON.stringify(sortedAndOrderedQuotas); //
    await AsyncStorage.setItem(QUOTAS_KEY, jsonValue); //
    return true;
  } catch (e) {
    console.error("Lỗi khi lưu định mức vào AsyncStorage:", e);
    return false;
  }
};

export const addQuotaToStorage = async (newQuotaData: Omit<Quota, 'id' | 'order'>): Promise<Quota | null> => {
  try {
    const quotas = await getQuotasFromStorage(); //
    if (quotas.some(q => q.stageCode.trim().toLowerCase() === newQuotaData.stageCode.trim().toLowerCase())) { //
      console.warn(`Mã công đoạn '${newQuotaData.stageCode}' đã tồn tại trong AsyncStorage.`); //
      return null;
    }
    const newQuota: Quota = {
      ...newQuotaData,
      id: uuidv4(), //
      order: quotas.length, //
    };
    const updatedQuotas = [...quotas, newQuota]; //
    await saveQuotasToStorage(updatedQuotas); //
    return newQuota;
  } catch (e) {
    console.error("Lỗi khi thêm định mức vào AsyncStorage:", e);
    return null;
  }
};

export const deleteQuotaFromStorage = async (quotaIdToDelete: string): Promise<boolean> => {
  try {
    let quotas = await getQuotasFromStorage(); //
    quotas = quotas.filter(q => q.id !== quotaIdToDelete); //
    const reorderedQuotas = quotas.map((q, index) => ({ ...q, order: index }));
    return await saveQuotasToStorage(reorderedQuotas); //
  } catch (e) {
    console.error("Lỗi khi xóa định mức từ AsyncStorage:", e);
    return false;
  }
};

export const updateQuotaInStorage = async (updatedQuota: Quota): Promise<Quota | null> => {
    try {
        const quotas = await getQuotasFromStorage(); //
        const index = quotas.findIndex(q => q.id === updatedQuota.id); //
        if (index === -1) {
            console.warn(`Không tìm thấy định mức với ID: ${updatedQuota.id} trong AsyncStorage để cập nhật.`); //
            return null;
        }
        if (quotas.some(q => q.id !== updatedQuota.id && q.stageCode.trim().toLowerCase() === updatedQuota.stageCode.trim().toLowerCase())) { //
            console.warn(`Mã công đoạn '${updatedQuota.stageCode}' đã tồn tại cho một định mức khác trong AsyncStorage.`); //
            return null;
        }
        quotas[index] = { ...quotas[index], ...updatedQuota }; //
        await saveQuotasToStorage(quotas); //
        return quotas[index]; //
    } catch (e) {
        console.error("Lỗi khi cập nhật định mức trong AsyncStorage:", e);
        return null;
    }
};

// --- Supabase Quota Settings & User Selected Quotas ---
export const getQuotaSettingByProductCode = async (productCode: string): Promise<QuotaSetting | null> => {
  try {
    console.log(`[Supabase] Searching for product_code: '${productCode}' in quota_settings.`);
    const { data, error } = await supabase
      .from('quota_settings')
      .select('*')
      .eq('product_code', productCode)
      .single();

    if (error) {
      if (error.code === 'PGRST116') { 
        console.log(`[Supabase] Product code '${productCode}' not found in quota_settings.`);
        return null;
      }
      console.error('[Supabase] Lỗi khi lấy chi tiết mã sản phẩm từ quota_settings:', error);
      return null;
    }
    console.log(`[Supabase] Found product_code '${productCode}':`, data);
    return data;
  } catch (e) {
    console.error('[Supabase] Exception khi lấy chi tiết mã sản phẩm:', e);
    return null;
  }
};

export const getUserSelectedQuotas = async (userId: string): Promise<UserSelectedQuota[]> => {
  if (!userId) {
    console.error("[Supabase] getUserSelectedQuotas: userId không được cung cấp.");
    return [];
  }
  try {
    console.log(`[Supabase] Fetching selected quotas for user_id: ${userId}`);
    const { data, error } = await supabase
      .from('user_selected_quotas')
      .select('*')
      .eq('user_id', userId)
      .order('zindex', { ascending: true });

    if (error) {
      console.error('[Supabase] Lỗi khi lấy danh sách định mức đã chọn của người dùng:', error);
      return []; 
    }
    console.log(`[Supabase] Fetched ${data?.length || 0} selected quotas for user ${userId}.`);
    return data || [];
  } catch (e) {
    console.error('[Supabase] Exception khi lấy danh sách định mức đã chọn:', e);
    return [];
  }
};

export const addUserSelectedQuota = async (
  userId: string,
  productCode: string,
  productName: string,
  zindex: number
): Promise<UserSelectedQuota | null> => {
  if (!userId || !productCode || !productName) {
    console.error("[Supabase] addUserSelectedQuota: Thiếu thông tin userId, productCode, hoặc productName.");
    return null;
  }
  try {
    console.log(`[Supabase] Checking if product ${productCode} already selected by user ${userId}.`);
    const { data: existing, error: existingError } = await supabase
      .from('user_selected_quotas')
      .select('product_code')
      .eq('user_id', userId)
      .eq('product_code', productCode)
      .maybeSingle();

    if (existingError && existingError.code !== 'PGRST116') { 
        console.error('[Supabase] Lỗi khi kiểm tra định mức đã tồn tại:', existingError);
        return null; 
    }

    if (existing) {
        console.warn(`[Supabase] Sản phẩm ${productCode} đã được người dùng ${userId} chọn.`);
        return null; 
    }

    console.log(`[Supabase] Adding product ${productCode} (${productName}) for user ${userId} with zindex ${zindex}.`);
    const { data, error } = await supabase
      .from('user_selected_quotas')
      .insert([{ user_id: userId, product_code: productCode, product_name: productName, zindex: zindex }])
      .select()
      .single();

    if (error) {
      console.error('[Supabase] Lỗi khi thêm định mức đã chọn:', error);
      return null;
    }
    console.log(`[Supabase] Successfully added product:`, data);
    return data;
  } catch (e) {
    console.error('[Supabase] Exception khi thêm định mức đã chọn:', e);
    return null;
  }
};

export const deleteUserSelectedQuota = async (userId: string, productCode: string): Promise<boolean> => {
  if (!userId || !productCode) {
    console.error("[Supabase] deleteUserSelectedQuota: Thiếu thông tin userId hoặc productCode.");
    return false;
  }
  try {
    console.log(`[Supabase] Attempting to delete product_code '${productCode}' for user_id '${userId}'.`);
    const { error, count } = await supabase
      .from('user_selected_quotas')
      .delete({ count: 'exact' }) 
      .eq('user_id', userId)
      .eq('product_code', productCode);

    if (error) {
      console.error(`[Supabase] Lỗi từ Supabase khi xóa product_code '${productCode}':`, error);
      return false; 
    }
    if (count !== null && count > 0) {
      console.log(`[Supabase] Successfully deleted product_code '${productCode}' for user_id '${userId}'. Count: ${count}`);
      return true;
    } else {
      console.warn(`[Supabase] No rows deleted for product_code '${productCode}', user_id '${userId}'. Count: ${count}. Điều này có thể do RLS hoặc item không tồn tại/không khớp.`);
      return false; 
    }
  } catch (e) {
    console.error(`[Supabase] Exception khi xóa product_code '${productCode}':`, e);
    return false;
  }
};

export const saveUserSelectedQuotasOrder = async (
  userId: string,
  quotas: Array<{ product_code: string; zindex: number }>
): Promise<boolean> => {
  if (!userId) {
    console.error("[Supabase] saveUserSelectedQuotasOrder: userId không được cung cấp.");
    return false;
  }
  if (!quotas) {
    console.warn("[Supabase] saveUserSelectedQuotasOrder: Mảng quotas không được cung cấp.");
    return true; 
  }
   if (quotas.length === 0) {
    console.log("[Supabase] saveUserSelectedQuotasOrder: Không có định mức nào để cập nhật thứ tự.");
    return true; 
  }

  try {
    console.log(`[Supabase] Attempting to save order for user ${userId}, quotas count: ${quotas.length}`);
        
    const updatePromises = quotas.map(q =>
      supabase
        .from('user_selected_quotas')
        .update({ zindex: q.zindex })
        .eq('user_id', userId)
        .eq('product_code', q.product_code)
    );

    const results = await Promise.all(updatePromises);
    let allSuccessful = true;

    results.forEach((result, index) => {
      const targetQuota = quotas[index];
      if (result.error) {
        console.error(`[Supabase] Lỗi khi cập nhật zindex cho product_code '${targetQuota.product_code}' (new zindex: ${targetQuota.zindex}):`, result.error);
        allSuccessful = false;
      }
    });

    if (!allSuccessful) {
      console.error('[Supabase] Một hoặc nhiều cập nhật thứ tự thất bại.');
      return false;
    }

    console.log(`[Supabase] Cập nhật thứ tự thành công cho tất cả các mục của user ${userId}.`);
    return true;
  } catch (e) {
    console.error('[Supabase] Exception khi cập nhật thứ tự định mức đã chọn:', e);
    return false;
  }
};

export const getUserProfile = async (userId: string): Promise<Profile | null> => {
  if (!userId) {
    console.error("[Supabase] getUserProfile: userId không được cung cấp.");
    return null;
  }
  try {
    console.log(`[Supabase] Fetching profile for user_id: ${userId}`);
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        console.warn(`[Supabase] Không tìm thấy profile cho user_id: ${userId}`);
      } else {
        console.error('[Supabase] Lỗi khi lấy profile người dùng:', error);
      }
      return null;
    }
    console.log(`[Supabase] Fetched profile for user ${userId}:`, data);
    return data;
  } catch (e) {
    console.error('[Supabase] Exception khi lấy profile người dùng:', e);
    return null;
  }
};

export const getQuotaValueBySalaryLevel = (
  quotaSetting: QuotaSetting | null,
  salaryLevel: string | null | undefined
): number => {
  if (!quotaSetting || !salaryLevel) {
    return 0;
  }
  const formattedSalaryLevel = `level_${salaryLevel.replace('.', '_')}`;
  if (Object.prototype.hasOwnProperty.call(quotaSetting, formattedSalaryLevel)) {
    const quotaValue = (quotaSetting as any)[formattedSalaryLevel];
    return typeof quotaValue === 'number' ? quotaValue : 0;
  }
  console.warn(`[Utils] Không tìm thấy cột định mức cho salary_level '${salaryLevel}' (key: '${formattedSalaryLevel}') trong QuotaSetting:`, quotaSetting);
  return 0; 
};

// --- Production Entry Management (Nhập sản lượng) AsyncStorage ---
export const getProductionEntriesFromStorage = async (): Promise<ProductionEntry[]> => {
  try {
    const jsonValue = await AsyncStorage.getItem(PRODUCTION_ENTRIES_KEY); //
    return jsonValue != null ? JSON.parse(jsonValue) : []; //
  } catch (e) {
    console.error("Lỗi khi tải dữ liệu sản lượng từ AsyncStorage:", e);
    return [];
  }
};

export const saveProductionEntriesToStorage = async (entries: ProductionEntry[]): Promise<boolean> => {
  try {
    const jsonValue = JSON.stringify(entries); //
    await AsyncStorage.setItem(PRODUCTION_ENTRIES_KEY, jsonValue); //
    return true;
  } catch (e) {
    console.error("Lỗi khi lưu dữ liệu sản lượng vào AsyncStorage:", e);
    return false;
  }
};

export const addOrUpdateProductionEntryInStorage = async (
  entryData: Omit<ProductionEntry, 'id'>
): Promise<ProductionEntry | null> => {
  try {
    let entries = await getProductionEntriesFromStorage(); //
    const existingEntryIndex = entries.findIndex(
      e => e.date === entryData.date && e.stageCode === entryData.stageCode
    ); //

    let resultEntry: ProductionEntry;

    if (existingEntryIndex > -1) { //
      entries[existingEntryIndex].quantity = entryData.quantity; //
      resultEntry = entries[existingEntryIndex]; //
    } else {
      const newEntry: ProductionEntry = { //
        ...entryData,
        id: uuidv4(), //
      };
      entries.push(newEntry); //
      resultEntry = newEntry; //
    }
    await saveProductionEntriesToStorage(entries); //
    return resultEntry;
  } catch (e) {
    console.error("Lỗi khi thêm/cập nhật sản lượng trong AsyncStorage:", e);
    return null;
  }
};

export const getProductionEntriesByDateFromStorage = async (date: string): Promise<ProductionEntry[]> => {
  const allEntries = await getProductionEntriesFromStorage(); //
  return allEntries.filter(entry => entry.date === date); //
};

export const getProductionEntriesByDateRangeFromStorage = async (
  startDate: string, 
  endDate: string   
): Promise<ProductionEntry[]> => {
  const allEntries = await getProductionEntriesFromStorage(); //
  return allEntries.filter(entry => entry.date >= startDate && entry.date <= endDate); //
};

export const deleteProductionEntryFromStorage = async (entryId: string): Promise<boolean> => {
    try {
        let entries = await getProductionEntriesFromStorage(); //
        entries = entries.filter(e => e.id !== entryId); //
        return await saveProductionEntriesToStorage(entries); //
    } catch (e) {
        console.error("Lỗi khi xóa sản lượng từ AsyncStorage:", e);
        return false;
    }
};

// --- Daily Supplementary Data Management (Nghỉ, Tăng ca, Họp) AsyncStorage ---
export const getAllSupplementaryDataFromStorage = async (): Promise<DailySupplementaryData[]> => {
  try {
    const jsonValue = await AsyncStorage.getItem(SUPPLEMENTARY_DATA_KEY); //
    return jsonValue != null ? JSON.parse(jsonValue) : []; //
  } catch (e) {
    console.error("Lỗi khi tải dữ liệu phụ trợ từ AsyncStorage:", e);
    return [];
  }
};

export const saveAllSupplementaryDataToStorage = async (data: DailySupplementaryData[]): Promise<boolean> => {
  try {
    const jsonValue = JSON.stringify(data); //
    await AsyncStorage.setItem(SUPPLEMENTARY_DATA_KEY, jsonValue); //
    return true;
  } catch (e) {
    console.error("Lỗi khi lưu dữ liệu phụ trợ vào AsyncStorage:", e);
    return false;
  }
};

export const addOrUpdateDailySupplementaryData = async (
  entryToUpdate: DailySupplementaryData
): Promise<DailySupplementaryData | null> => {
  try {
    let allSuppData = await getAllSupplementaryDataFromStorage(); //
    const existingEntryIndex = allSuppData.findIndex(e => e.date === entryToUpdate.date); //

    if (existingEntryIndex > -1) { //
      const existingEntry = allSuppData[existingEntryIndex]; //
      allSuppData[existingEntryIndex] = { //
        ...existingEntry,
        ...entryToUpdate, 
      };
      if (entryToUpdate.leaveHours === null) allSuppData[existingEntryIndex].leaveHours = null; //
      if (entryToUpdate.overtimeHours === null) allSuppData[existingEntryIndex].overtimeHours = null; //
      if (entryToUpdate.meetingMinutes === null) allSuppData[existingEntryIndex].meetingMinutes = null; //

    } else {
      allSuppData.push(entryToUpdate); //
    }
    allSuppData = allSuppData.filter(entry => //
        entry.leaveHours != null || entry.overtimeHours != null || entry.meetingMinutes != null
    );

    await saveAllSupplementaryDataToStorage(allSuppData); //
    const finalEntry = allSuppData.find(e => e.date === entryToUpdate.date); //
    return finalEntry || null; //
  } catch (e) {
    console.error("Lỗi khi thêm/cập nhật dữ liệu phụ trợ trong AsyncStorage:", e);
    return null;
  }
};

export const getSupplementaryDataByDateFromStorage = async (date: string): Promise<DailySupplementaryData | null> => {
  const allSuppData = await getAllSupplementaryDataFromStorage(); //
  return allSuppData.find(entry => entry.date === date) || null; //
};

export const getSupplementaryDataByDateRangeFromStorage = async (
  startDate: string, 
  endDate: string   
): Promise<DailySupplementaryData[]> => {
  const allSuppData = await getAllSupplementaryDataFromStorage(); //
  return allSuppData.filter(entry => entry.date >= startDate && entry.date <= endDate); //
};

// --- Tiện ích ---
export const clearAllLocalData = async () => { 
    try {
        await AsyncStorage.removeItem(QUOTAS_KEY); //
        await AsyncStorage.removeItem(PRODUCTION_ENTRIES_KEY); //
        await AsyncStorage.removeItem(SUPPLEMENTARY_DATA_KEY); //
        console.log("Đã xóa toàn bộ dữ liệu AsyncStorage."); //
    } catch (e) {
        console.error("Lỗi khi xóa toàn bộ dữ liệu AsyncStorage:", e); //
    }
}