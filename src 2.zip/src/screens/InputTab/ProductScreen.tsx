// src/screens/InputTab/ProductScreen.tsx
import React, { useState, useEffect, useCallback, useLayoutEffect, lazy, Suspense } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Platform, ScrollView, TouchableOpacity } from 'react-native';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import type { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { addDays } from 'date-fns';

import { InputStackNavigatorParamList } from '../../navigation/types';
import { theme } from '../../theme';
import { ProductionEntry } from '../../types/data';
import { supabase } from '../../services/supabase';
import { deleteProductionEntry } from '../../services/storage'; // Chỉ cần hàm delete
import { getToday } from '../../utils/dateUtils';
import WeeklyPage from './components/WeeklyPage';
import Button from '../../components/common/Button';
import AlertModal, { AlertButtonType } from '../../components/common/AlertModal';
// import EditEntryModal from './components/EditEntryModal'; // Xóa bỏ EditEntryModal
import { useProductionStore } from '../../stores/productionStore';

if (Platform.OS === 'web') {
  const styleId = 'hide-scrollbar-style';
  if (!document.getElementById(styleId)) {
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `.scrollable-slide::-webkit-scrollbar { display: none; } .scrollable-slide { -ms-overflow-style: none; scrollbar-width: none; }`;
    document.head.appendChild(style);
  }
}

const PagerView = Platform.OS !== 'web' ? lazy(() => import('react-native-pager-view')) : null;
type ProductScreenNavigationProp = StackNavigationProp<InputStackNavigatorParamList, 'ProductList'>;
export interface ProcessedWeekData {
  weekInfo: import('../../utils/dateUtils').EstronWeekPeriod;
  dailyData: import('../../types/data').DailyProductionData[];
  totalWeeklyWork: number;
}

export default function ProductScreen() {
  const navigation = useNavigation<ProductScreenNavigationProp>();

  const {
    userSelectedQuotas,
    processedWeeksData,
    estronWeekInfo,
    isLoading,
    targetDate,
    isViewingPreviousMonth,
    currentPageIndex,
    setCurrentPageIndex,
    initialize,
    cleanup,
    setTargetDate,
  } = useProductionStore();

  const [userId, setUserId] = useState<string | null>(null);
  // Các state liên quan đến modal đã được xóa
  const [isCustomAlertVisible, setIsCustomAlertVisible] = useState(false);
  const [customAlertMessage, setCustomAlertMessage] = useState('');
  const [customAlertButtons, setCustomAlertButtons] = useState<AlertButtonType[]>([]);

  const showAlert = (message: string, buttons?: AlertButtonType[]) => {
    setCustomAlertMessage(message);
    setCustomAlertButtons(buttons || [{ text: 'OK', onPress: () => setIsCustomAlertVisible(false) }]);
    setIsCustomAlertVisible(true);
  };
  const closeAlert = () => setIsCustomAlertVisible(false);

  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user) setUserId(user.id);
      else showAlert('Không tìm thấy thông tin người dùng để tải dữ liệu.');
    };
    fetchUser();
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (userId) {
        initialize(userId);
      }
      return () => {
        cleanup();
      };
    }, [userId, initialize, cleanup])
  );
  
  const handleNavigateToPreviousMonth = useCallback(() => {
    if (estronWeekInfo) {
      const previousMonthDate = addDays(estronWeekInfo.estronMonth.startDate, -1);
      setTargetDate(previousMonthDate);
    }
  }, [estronWeekInfo, setTargetDate]);

  const handleNavigateToCurrentMonth = useCallback(() => {
    setTargetDate(getToday());
  }, [setTargetDate]);

  useLayoutEffect(() => {
    if (estronWeekInfo) {
      navigation.setOptions({
        title: `Sản lượng tháng ${estronWeekInfo.estronMonth.estronMonth}`,
        headerLeft: () => (
          <TouchableOpacity
            onPress={isViewingPreviousMonth ? handleNavigateToCurrentMonth : handleNavigateToPreviousMonth}
            style={{
              marginLeft: Platform.OS === 'ios' ? theme.spacing['level-2'] : theme.spacing['level-4'],
              padding: theme.spacing['level-1'],
            }}
          >
            <Ionicons
              name={isViewingPreviousMonth ? 'caret-forward' : 'caret-back'}
              size={26}
              color={theme.colors.textOnPrimary}
            />
          </TouchableOpacity>
        ),
      });
    } else {
      navigation.setOptions({ title: 'Sản Lượng Estron', headerLeft: () => null });
    }
  }, [navigation, estronWeekInfo, isViewingPreviousMonth, handleNavigateToPreviousMonth, handleNavigateToCurrentMonth]);

  const handleAddProduction = (date: string) => {
    navigation.navigate('InputDetails', { date });
  };
  
  // Sửa hàm này để điều hướng đến InputScreen
  const handleEditEntry = (entry: ProductionEntry) => {
    if (entry.verified) {
      showAlert('Mục này đã được xác nhận và không thể sửa.');
      return;
    }
    // Truyền entryId qua params
    navigation.navigate('InputDetails', { entryId: entry.id });
  };


  if (isLoading && processedWeeksData.length === 0) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
        <Text style={{ color: theme.colors.textSecondary, marginTop: theme.spacing['level-2'] }}>
          Đang tải dữ liệu...
        </Text>
      </View>
    );
  }
  if (!userId && !isLoading) {
    return (
      <View style={styles.centered}>
        <Text style={styles.emptyText}>Không thể tải dữ liệu do chưa xác thực người dùng.</Text>
      </View>
    );
  }
  if (userId && !isLoading && (!estronWeekInfo || processedWeeksData.length === 0)) {
    return (
      <View style={styles.centered}>
        <Text style={styles.emptyText}>Không có dữ liệu tuần để hiển thị cho tháng này.</Text>
        <Button title="Tải lại" onPress={() => initialize(userId)} style={{ marginTop: theme.spacing['level-4'] }} />
      </View>
    );
  }

  const pagerKey = `${userId}-${processedWeeksData.length}-${currentPageIndex}-${Platform.OS}-${targetDate.toISOString()}`;

  return (
    <View style={styles.container}>
      {userId &&
        processedWeeksData.length > 0 &&
        (Platform.OS === 'web' ? (
          <Swiper
            style={styles.pagerView}
            initialSlide={currentPageIndex}
            onSlideChange={swiper => setCurrentPageIndex(swiper.activeIndex)}
            key={pagerKey}
          >
            {processedWeeksData.map(weekData => (
              <SwiperSlide
                key={weekData.weekInfo.name + weekData.weekInfo.startDate.toISOString()}
                className="scrollable-slide"
                style={{ height: '100%', overflow: 'auto' }}
              >
                <WeeklyPage
                  userId={userId}
                  weekData={weekData}
                  quotasExist={userSelectedQuotas.length > 0}
                  onAddProduction={handleAddProduction}
                  onEditEntry={handleEditEntry} // Dùng hàm mới
                />
              </SwiperSlide>
            ))}
          </Swiper>
        ) : (
          PagerView && (
            <Suspense fallback={<ActivityIndicator size="large" color={theme.colors.primary} />}>
              <PagerView
                style={styles.pagerView}
                initialPage={currentPageIndex}
                onPageSelected={e => setCurrentPageIndex(e.nativeEvent.position)}
                key={pagerKey}
              >
                {processedWeeksData.map((weekData, index) => (
                  <View key={index} style={styles.fullFlex}>
                    <ScrollView showsVerticalScrollIndicator={false}>
                      <WeeklyPage
                        userId={userId}
                        weekData={weekData}
                        quotasExist={userSelectedQuotas.length > 0}
                        onAddProduction={handleAddProduction}
                        onEditEntry={handleEditEntry} // Dùng hàm mới
                      />
                    </ScrollView>
                  </View>
                ))}
              </PagerView>
            </Suspense>
          )
        ))}
      
      {/* EditEntryModal đã được xóa bỏ */}
      <AlertModal
        visible={isCustomAlertVisible}
        message={customAlertMessage}
        buttons={customAlertButtons}
        onClose={closeAlert}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background1 },
  pagerView: { flex: 1, width: '100%' },
  fullFlex: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: theme.spacing['level-6'] },
  emptyText: {
    fontSize: theme.typography.fontSize['level-4'],
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginBottom: theme.spacing['level-2'],
  },
});