// src/screens/InputTab/components/DailyCard.tsx
import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';

import { theme } from '../../../theme';
import { DailyProductionData } from '../../../types/data';
import Card from '../../../components/common/Card'; //
import EntryRow from './EntryRow';
import AdditionalInfo from './AdditionalInfo';
import { EntryInfoForDelete } from '../ProductScreen'; // Assuming type is moved or accessible

interface DailyCardProps {
  dailyInfo: DailyProductionData;
  weekHasData: boolean;
  onAddProduction: (date: string) => void;
  onAttemptDeleteEntry?: (entryInfo: EntryInfoForDelete) => void;
}

const DailyCard: React.FC<DailyCardProps> = ({
  dailyInfo,
  weekHasData,
  onAddProduction,
  onAttemptDeleteEntry,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  // isFullDayLeave is now managed here, passed to AdditionalInfo, and updated by it.
  const [isFullDayLeave, setIsFullDayLeave] = useState(false);


  const handleFullDayLeaveChange = (isFullDay: boolean) => {
    setIsFullDayLeave(isFullDay);
  };

  return (
    <Card style={styles.dailyCard}>
      <View style={styles.cardHeader}>
        <Text style={styles.cardDateText}>{`${dailyInfo.dayOfWeek}, ${dailyInfo.formattedDate}`}</Text>
        {weekHasData && <Text style={styles.cardTotalWorkText}>Tổng công: {dailyInfo.totalWorkForDay != null ? dailyInfo.totalWorkForDay.toLocaleString() : '0'}</Text>}
      </View>

      <View style={styles.entriesContainer}>
        {dailyInfo.entries.length > 0 ? (
          dailyInfo.entries.map((entry, index) => (
            <React.Fragment key={entry.id}>
              <EntryRow
                entry={entry}
                onLongPress={() => {
                  if (onAttemptDeleteEntry && entry.id && !isFullDayLeave) {
                    onAttemptDeleteEntry({
                      id: entry.id,
                      stageCode: entry.stageCode,
                      quantity: entry.quantity,
                    });
                  }
                }}
                disabled={isFullDayLeave}
              />
              {dailyInfo.entries.length > 1 && index < dailyInfo.entries.length - 1 && (
                <View style={styles.divider} />
              )}
            </React.Fragment>
          ))
        ) : (
          <Text style={[styles.noEntryText, isFullDayLeave && styles.disabledText]}>Chưa có dữ liệu</Text>
        )}
      </View>

      <View style={styles.footerActionContainer}>
        <TouchableOpacity
          style={[styles.addProductionButton, isFullDayLeave && styles.disabledButton]}
          onPress={() => {
            if (!isFullDayLeave) {
              onAddProduction(dailyInfo.date);
            }
          }}
          disabled={isFullDayLeave}
        >
          <Ionicons name="add-circle-outline" size={22} color={isFullDayLeave ? theme.colors.grey : theme.colors.primary} />
          <Text style={[styles.addProductionButtonText, isFullDayLeave && { color: theme.colors.grey }]}>Thêm sản lượng</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.expandButton}
          onPress={() => setIsExpanded(!isExpanded)}
        >
          <Ionicons
            name={isExpanded ? "chevron-up-outline" : "chevron-down-outline"}
            size={24}
            color={theme.colors.secondary}
          />
        </TouchableOpacity>
      </View>

      {isExpanded && (
        <AdditionalInfo
            date={dailyInfo.date}
            isFullDayLeave={isFullDayLeave}
            onFullDayLeaveChange={handleFullDayLeaveChange}
        />
      )}
    </Card>
  );
};

const styles = StyleSheet.create({
  dailyCard: {
    marginVertical: theme.spacing.sm,
    padding: 0, // Card component might have its own padding, ensure this is intended
    borderRadius: theme.borderRadius.md,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: theme.colors.borderColor,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: theme.spacing.sm,
    paddingTop: theme.spacing.sm,
    paddingHorizontal: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.borderColor,
    backgroundColor: theme.colors.lightGrey,
  },
  cardDateText: {
    fontSize: theme.typography.body.fontSize,
    fontWeight: 'bold',
    color: theme.colors.text,
  },
  cardTotalWorkText: {
    fontSize: theme.typography.bodySmall.fontSize,
    fontWeight: 'bold',
    color: theme.colors.info,
  },
  entriesContainer: {
    paddingBottom: theme.spacing.xs,
  },
  noEntryText: {
    fontSize: theme.typography.bodySmall.fontSize,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    paddingVertical: theme.spacing.md,
    paddingHorizontal: theme.spacing.md,
  },
  divider: {
    height: 1,
    backgroundColor: theme.colors.borderColor,
    marginHorizontal: theme.spacing.md,
  },
  footerActionContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: theme.spacing.xs,
    paddingHorizontal: theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: theme.colors.lightGrey,
  },
  addProductionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: theme.spacing.sm / 2,
  },
  addProductionButtonText: {
    marginLeft: theme.spacing.xs,
    color: theme.colors.primary,
    fontSize: theme.typography.bodySmall.fontSize,
    fontWeight: 'bold',
  },
  expandButton: {
    padding: theme.spacing.sm,
  },
  disabledButton: {
    // backgroundColor: theme.colors.lightGrey, // Already applied by EntryRow/AdditionalInfo if needed
    // borderColor: theme.colors.grey,
    opacity: 0.7,
  },
  disabledText: {
    color: theme.colors.grey,
  },
});

export default DailyCard;