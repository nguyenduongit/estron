// src/screens/InputTab/components/WeeklyPage.tsx
import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { theme } from '../../../theme';
import { DailyProductionData, Quota } from '../../../types/data';
import { EstronWeekPeriod, formatDate } from '../../../utils/dateUtils'; //
import DailyCard from './DailyCard';
import { EntryInfoForDelete } from '../ProductScreen'; // Assuming type is moved or accessible

interface ProcessedWeekData {
  weekInfo: EstronWeekPeriod;
  dailyData: DailyProductionData[];
  totalWeeklyWork: number;
}

interface WeeklyPageProps {
  weekData: ProcessedWeekData;
  quotasExist: boolean; // Renamed from weekHasData for clarity at this level
  onAddProduction: (date: string) => void;
  onAttemptDeleteEntry: (entryInfo: EntryInfoForDelete, formattedDate: string) => void;
}

const WeeklyPage: React.FC<WeeklyPageProps> = ({
  weekData,
  quotasExist,
  onAddProduction,
  onAttemptDeleteEntry,
}) => {
  return (
    <View style={styles.pageStyle}>
      <View style={styles.weekHeader}>
        <View>
          <Text style={styles.weekName}>{weekData.weekInfo.name}</Text>
          <Text style={styles.weekDateRange}>
            ({formatDate(weekData.weekInfo.startDate, 'dd/MM')} - {formatDate(weekData.weekInfo.endDate, 'dd/MM')})
          </Text>
        </View>
        {quotasExist && (
          <Text style={styles.totalWeeklyWorkText}>
            Tổng công tuần: {weekData.totalWeeklyWork != null ? weekData.totalWeeklyWork.toLocaleString() : '0'}
          </Text>
        )}
      </View>
      <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }} contentContainerStyle={{ paddingHorizontal: theme.spacing.sm }}>
        {weekData.dailyData.map(day => (
          <DailyCard
            key={day.date}
            dailyInfo={day}
            weekHasData={quotasExist} // Pass down the renamed prop
            onAddProduction={onAddProduction}
            onAttemptDeleteEntry={(entryInfo) => onAttemptDeleteEntry(entryInfo, day.formattedDate)}
          />
        ))}
        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  pageStyle: {
    flex: 1,
    paddingHorizontal: theme.spacing.sm,
    
  },
  weekHeader: {
    paddingVertical: theme.spacing.md,
    paddingHorizontal: theme.spacing.sm,
    marginHorizontal: -theme.spacing.sm, // To make border full width if pageStyle has horizontal padding
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.borderColor,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: theme.colors.lightGrey,
  },
  weekName: {
    fontSize: theme.typography.h3.fontSize,
    fontWeight: theme.typography.h3.fontWeight,
    color: theme.colors.primary,
  },
  weekDateRange: {
    fontSize: theme.typography.caption.fontSize,
    color: theme.colors.textSecondary,
  },
  totalWeeklyWorkText: {
    fontSize: theme.typography.body.fontSize,
    fontWeight: 'bold',
    color: theme.colors.success,
  },
});

export default WeeklyPage;