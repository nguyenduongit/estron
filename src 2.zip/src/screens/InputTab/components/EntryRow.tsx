// src/screens/InputTab/components/EntryRow.tsx
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { theme } from '../../../theme';
import { DailyProductionData } from '../../../types/data'; //

interface EntryRowProps {
  entry: DailyProductionData['entries'][0];
  onLongPress?: () => void;
  disabled?: boolean;
}

const EntryRow: React.FC<EntryRowProps> = ({ entry, onLongPress, disabled }) => {
  return (
    <TouchableOpacity onLongPress={onLongPress} disabled={disabled || !onLongPress}>
      <View style={[styles.entryRow, disabled && styles.disabledTextContainer]}>
        <Text style={[styles.entryStageCode, disabled && styles.disabledText]}>{entry.stageCode}</Text>
        <Text style={[styles.entryQuantity, disabled && styles.disabledText]}>{entry.quantity.toLocaleString()}</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  entryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
  },
  entryStageCode: {
    fontSize: theme.typography.bodySmall.fontSize,
    fontWeight: 'bold',
    color: theme.colors.text,
  },
  entryQuantity: {
    fontSize: theme.typography.bodySmall.fontSize,
    fontWeight: 'bold',
    color: theme.colors.text,
  },
  disabledTextContainer: {
    opacity: 0.6,
  },
  disabledText: {
    color: theme.colors.grey,
  },
});

export default EntryRow;