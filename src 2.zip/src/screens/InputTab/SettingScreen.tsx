// screens/InputTab/SettingScreen.tsx
import React, { useState, useEffect, useLayoutEffect, useCallback, useRef } from 'react';
import { View, Text, StyleSheet, Alert, ActivityIndicator, TouchableOpacity, Keyboard } from 'react-native';
import type { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation, useIsFocused } from '@react-navigation/native';
import DraggableFlatList, { RenderItemParams, ScaleDecorator } from 'react-native-draggable-flatlist';
import Ionicons from '@expo/vector-icons/Ionicons';

import { InputStackNavigatorParamList } from '../../navigation/types';
import { theme } from '../../theme';
import { UserSelectedQuota, QuotaSetting } from '../../types/data'; // Sử dụng UserSelectedQuota
import { supabase } from '../../services/supabase'; // Để lấy user_id
import {
  getQuotaSettingByProductCode,
  getUserSelectedQuotas,
  addUserSelectedQuota,
  deleteUserSelectedQuota,
  saveUserSelectedQuotasOrder,
} from '../../services/storage'; // Sử dụng các hàm Supabase mới

import Button from '../../components/common/Button';
import TextInput from '../../components/common/TextInput';
import ModalWrapper from '../../components/common/ModalWrapper';

type SettingScreenNavigationProp = StackNavigationProp<InputStackNavigatorParamList, 'Settings'>;

// Interface cho dữ liệu form trong modal
interface ProductCodeFormData {
  productCode: string;
}

export default function SettingScreen() {
  const navigation = useNavigation<SettingScreenNavigationProp>();
  const isFocused = useIsFocused();

  const [userSelectedQuotas, setUserSelectedQuotas] = useState<UserSelectedQuota[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);

  // State cho modal thêm mới
  const [currentProductCodeInput, setCurrentProductCodeInput] = useState('');
  const [foundProduct, setFoundProduct] = useState<QuotaSetting | null>(null);
  const [productSearchMessage, setProductSearchMessage] = useState<string | null>(null);
  const [productSearchMessageType, setProductSearchMessageType] = useState<'success' | 'error' | null>(null);
  const [isSearchingProduct, setIsSearchingProduct] = useState(false);

  const [userId, setUserId] = useState<string | null>(null);
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);


  // Lấy user ID khi component mount hoặc focus
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          setUserId(user.id);
        } else {
          Alert.alert("Lỗi", "Không thể xác thực người dùng. Vui lòng đăng nhập lại.");
          // Có thể điều hướng về màn hình đăng nhập
        }
      } catch (error) {
        console.error("Lỗi lấy thông tin người dùng:", error);
        Alert.alert("Lỗi", "Có lỗi xảy ra khi lấy thông tin người dùng.");
      }
    };
    fetchUser();
  }, []);

  const loadUserQuotas = useCallback(async () => {
    if (!userId) return;
    setIsLoading(true);
    try {
      const storedQuotas = await getUserSelectedQuotas(userId);
      setUserSelectedQuotas(storedQuotas);
    } catch (error) {
      Alert.alert("Lỗi", "Không thể tải danh sách định mức đã chọn.");
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    if (isFocused && userId) {
      loadUserQuotas();
      if (!isModalVisible) {
        setIsEditMode(false);
      }
    }
  }, [isFocused, userId, loadUserQuotas, isModalVisible]);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          onPress={() => {
            if (isEditMode) {
              handleSaveOrder();
            } else {
              setIsEditMode(true);
            }
          }}
          style={{ marginRight: theme.spacing.md, padding: theme.spacing.xs }}
        >
          <Text style={{ color: theme.colors.white, fontSize: 16, fontWeight: 'bold' }}>
            {isEditMode ? 'Lưu Sắp Xếp' : 'Sửa Thứ Tự'}
          </Text>
        </TouchableOpacity>
      ),
    });
  }, [navigation, isEditMode, userSelectedQuotas]); // Thêm userSelectedQuotas để re-render khi cần

  const handleOpenModal = () => {
    setCurrentProductCodeInput('');
    setFoundProduct(null);
    setProductSearchMessage(null);
    setProductSearchMessageType(null);
    setIsModalVisible(true);
  };

  const handleCloseModal = () => {
    setIsModalVisible(false);
    // Reset các state của modal
    setCurrentProductCodeInput('');
    setFoundProduct(null);
    setProductSearchMessage(null);
    setProductSearchMessageType(null);
  };

  const handleProductCodeChange = (text: string) => {
    const upperCaseText = text.toUpperCase();
    setCurrentProductCodeInput(upperCaseText);
    setFoundProduct(null);
    setProductSearchMessage(null);
    setProductSearchMessageType(null);

    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    if (upperCaseText.trim() === '') {
      setIsSearchingProduct(false);
      return;
    }
    
    setIsSearchingProduct(true);
    searchTimeoutRef.current = setTimeout(async () => {
      try {
        const productDetails = await getQuotaSettingByProductCode(upperCaseText.trim());
        if (productDetails) {
          setFoundProduct(productDetails);
          setProductSearchMessage(`Tên SP: ${productDetails.product_name}`);
          setProductSearchMessageType('success');
        } else {
          setFoundProduct(null);
          setProductSearchMessage(`Mã sản phẩm '${upperCaseText.trim()}' không tồn tại.`);
          setProductSearchMessageType('error');
        }
      } catch (error) {
        setFoundProduct(null);
        setProductSearchMessage("Lỗi khi tra cứu mã sản phẩm.");
        setProductSearchMessageType('error');
      } finally {
        setIsSearchingProduct(false);
      }
    }, 1000); // Debounce 1 giây
  };


  const handleAddProduct = async () => {
    if (!userId || !foundProduct || !currentProductCodeInput.trim()) {
      Alert.alert("Lỗi", "Vui lòng nhập mã sản phẩm hợp lệ và đã được tìm thấy.");
      return;
    }

    // Kiểm tra xem sản phẩm đã có trong danh sách userSelectedQuotas chưa
    const isAlreadyAdded = userSelectedQuotas.some(
        (quota) => quota.product_code === foundProduct.product_code
    );

    if (isAlreadyAdded) {
        Alert.alert("Thông báo", `Sản phẩm '${foundProduct.product_code}' đã có trong danh sách của bạn.`);
        return;
    }


    setIsLoading(true);
    Keyboard.dismiss();
    try {
      const newOrder = userSelectedQuotas.length; // Thứ tự mới là ở cuối danh sách
      const addedQuota = await addUserSelectedQuota(
        userId,
        foundProduct.product_code,
        foundProduct.product_name,
        newOrder
      );

      if (addedQuota) {
        // setUserSelectedQuotas(prev => [...prev, addedQuota]); // Thêm vào state local
        await loadUserQuotas(); // Tải lại danh sách từ server để đảm bảo nhất quán
        handleCloseModal();
        Alert.alert("Thành công", `Đã thêm sản phẩm '${addedQuota.product_name}'.`);
      } else {
        // addUserSelectedQuota sẽ log lỗi hoặc trả về null nếu đã tồn tại (dựa trên logic cập nhật trong hàm đó)
         Alert.alert("Lỗi", `Không thể thêm sản phẩm. Mã '${foundProduct.product_code}' có thể đã tồn tại hoặc có lỗi khác.`);
      }
    } catch (error) {
      console.error("Lỗi khi thêm sản phẩm vào danh sách đã chọn:", error);
      Alert.alert("Lỗi", "Đã có lỗi xảy ra khi thêm sản phẩm.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteQuota = (productCodeToDelete: string) => {
    if (!userId) return;
    const quotaToDelete = userSelectedQuotas.find(q => q.product_code === productCodeToDelete);
    if (!quotaToDelete) return;

    Alert.alert(
      'Xác nhận xóa',
      `Bạn có chắc chắn muốn xóa '${quotaToDelete.product_name}' (${quotaToDelete.product_code}) khỏi danh sách?`,
      [
        { text: 'Hủy', style: 'cancel' },
        {
          text: 'Xóa',
          style: 'destructive',
          onPress: async () => {
            setIsLoading(true);
            const success = await deleteUserSelectedQuota(userId, productCodeToDelete);
            if (success) {
              // Cập nhật lại state và thứ tự
              const updatedQuotas = userSelectedQuotas
                .filter(q => q.product_code !== productCodeToDelete)
                .map((q, index) => ({ ...q, zindex: index }));
              
              setUserSelectedQuotas(updatedQuotas);
              // Sau khi xóa, cần cập nhật lại zindex trên server cho các item còn lại
              if (updatedQuotas.length > 0) {
                 await saveUserSelectedQuotasOrder(userId, updatedQuotas.map(q => ({ product_code: q.product_code, zindex: q.zindex })));
              }
              Alert.alert("Đã xóa", `'${quotaToDelete.product_name}' đã được xóa.`);
            } else {
              Alert.alert("Lỗi", "Không thể xóa định mức.");
            }
            setIsLoading(false);
          },
        },
      ]
    );
  };

  const handleSaveOrder = async () => {
    if (!userId) return;
    setIsLoading(true);
    const success = await saveUserSelectedQuotasOrder(
      userId,
      userSelectedQuotas.map(q => ({ product_code: q.product_code, zindex: q.zindex }))
    );
    if (success) {
      Alert.alert("Đã lưu", "Thứ tự định mức đã được cập nhật.");
    } else {
      Alert.alert("Lỗi", "Không thể lưu thứ tự định mức.");
      // Tải lại dữ liệu từ server để tránh sai lệch nếu lưu thất bại
      await loadUserQuotas();
    }
    setIsEditMode(false);
    setIsLoading(false);
  };

  const renderQuotaItem = ({ item, drag, isActive }: RenderItemParams<UserSelectedQuota>): React.ReactNode => {
    return (
      <ScaleDecorator>
        <TouchableOpacity
          onLongPress={isEditMode ? drag : undefined}
          disabled={isActive}
          style={[
            styles.itemContainer,
            isActive && styles.itemActive,
          ]}
          // Không cần onPress ở đây nữa vì sửa/xem chi tiết không áp dụng trực tiếp từ item này
        >
          {isEditMode && (
            <TouchableOpacity onPress={() => handleDeleteQuota(item.product_code)} style={styles.deleteButton}>
              <Ionicons name="remove-circle" size={26} color={theme.colors.danger} />
            </TouchableOpacity>
          )}
          <View style={styles.itemTextContainer}>
            <Text style={styles.itemProductCode}>{item.product_code}</Text>
            <Text style={styles.itemProductName}>{item.product_name}</Text>
          </View>
          {isEditMode ? (
            <TouchableOpacity onPressIn={drag} disabled={isActive} style={styles.dragHandle}>
                 <Ionicons name="reorder-three-outline" size={30} color={theme.colors.grey} />
            </TouchableOpacity>
          ) : (
            // Có thể hiển thị một icon khác hoặc không gì cả nếu không ở edit mode
            <View style={{width: 30}} /> // Placeholder để giữ layout cân đối
          )}
        </TouchableOpacity>
      </ScaleDecorator>
    );
  };

  if (isLoading && !isModalVisible && !isSearchingProduct) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {userSelectedQuotas.length === 0 && !isLoading ? (
        <View style={styles.centered}>
            <Text style={styles.emptyText}>Chưa có định mức nào được chọn.</Text>
            <Text style={styles.emptyText}>Nhấn "Thêm Định Mức" để bắt đầu.</Text>
        </View>
      ) : (
        <DraggableFlatList
          data={userSelectedQuotas}
          renderItem={renderQuotaItem}
          keyExtractor={(item) => `${item.user_id}-${item.product_code}`} // Key duy nhất
          onDragEnd={({ data: reorderedData }) => {
            // Cập nhật state và zindex ngay lập tức
            const updatedDataWithNewZIndex = reorderedData.map((q, index) => ({ ...q, zindex: index }));
            setUserSelectedQuotas(updatedDataWithNewZIndex);
          }}
          containerStyle={{ flex: 1 }}
          ListHeaderComponent={<View style={{height: theme.spacing.sm}} />}
          ListFooterComponent={<View style={{height: isEditMode ? theme.spacing.sm : 80}}/>} // Thêm không gian cho nút "Thêm" nếu không ở edit mode
        />
      )}

      {!isEditMode && (
        <Button
          title="Thêm Định Mức Mới"
          onPress={handleOpenModal}
          style={styles.addButton}
          // icon={<Ionicons name="add-circle-outline" size={20} color={theme.colors.white} style={{marginRight: theme.spacing.sm}}/>}
        />
      )}

      <ModalWrapper
        visible={isModalVisible}
        onClose={handleCloseModal}
      >
        <View style={styles.customModalHeaderContainer}>
          <Text style={styles.customModalHeaderText}>Thêm Định Mức</Text>
        </View>
        <View style={styles.modalInnerContent}>
          <TextInput
            label="Mã Sản Phẩm (Product Code)"
            value={currentProductCodeInput}
            onChangeText={handleProductCodeChange}
            placeholder="Ví dụ: 5.2KA, L001..."
            autoCapitalize="characters"
            maxLength={20} // Giới hạn độ dài nếu cần
          />
          {isSearchingProduct && <ActivityIndicator size="small" color={theme.colors.primary} style={{ marginVertical: theme.spacing.sm }}/>}
          {productSearchMessage && (
            <Text style={[
              styles.productSearchMessage,
              productSearchMessageType === 'success' && styles.successText,
              productSearchMessageType === 'error' && styles.errorTextModal,
            ]}>
              {productSearchMessage}
            </Text>
          )}

          <View style={styles.modalActions}>
            <Button title="Hủy" onPress={handleCloseModal} type="secondary" style={styles.modalButton} />
            <Button
              title={isLoading ? "Đang thêm..." : "Thêm vào danh sách"}
              onPress={handleAddProduct}
              type="primary"
              style={styles.modalButton}
              disabled={isLoading || !foundProduct || isSearchingProduct} // Disable nếu đang tải hoặc không tìm thấy SP
            />
          </View>
        </View>
      </ModalWrapper>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  customModalHeaderContainer: {
    paddingBottom: theme.spacing.md,
    marginBottom: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.borderColor,
    alignItems: 'center',
  },
  customModalHeaderText: {
    fontSize: theme.typography.h3.fontSize,
    fontWeight: theme.typography.h3.fontWeight,
    color: theme.colors.text,
  },
  modalInnerContent: {
     paddingHorizontal: theme.spacing.xs, // Thêm padding nhỏ cho nội dung modal
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.lg,
  },
  emptyText: {
    fontSize: theme.typography.body.fontSize,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginBottom: theme.spacing.sm,
  },
  itemContainer: {
    backgroundColor: theme.colors.white,
    paddingVertical: theme.spacing.md,
    paddingHorizontal: theme.spacing.md,
    marginHorizontal: theme.spacing.md,
    marginVertical: theme.spacing.xs + 2,
    borderRadius: theme.borderRadius.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...theme.shadow.sm,
    borderWidth: 1,
    borderColor: theme.colors.lightGrey,
  },
  itemActive: {
    ...theme.shadow.lg,
    backgroundColor: theme.colors.light,
    borderColor: theme.colors.primary,
  },
  itemTextContainer: {
    flex: 1,
    marginRight: theme.spacing.sm,
  },
  itemProductCode: { // Đổi tên từ itemStageCode
    fontSize: theme.typography.h4.fontSize,
    fontWeight: theme.typography.h4.fontWeight,
    color: theme.colors.primary, // Màu khác cho nổi bật
  },
  itemProductName: { // Đổi tên từ itemDailyQuota
    fontSize: theme.typography.bodySmall.fontSize,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
  },
  deleteButton: {
    marginRight: theme.spacing.md,
    padding: theme.spacing.xs,
  },
  dragHandle: {
    // marginLeft: theme.spacing.sm, // Không cần nếu icon chiếm đủ không gian
    padding: theme.spacing.xs,
  },
  addButton: {
    marginHorizontal: theme.spacing.lg,
    marginVertical: theme.spacing.md,
    position: 'absolute',
    bottom: theme.spacing.md,
    left: theme.spacing.md,
    right: theme.spacing.md,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: theme.spacing.lg,
    marginBottom: theme.spacing.sm,
  },
  modalButton: {
    flex: 1,
    marginHorizontal: theme.spacing.sm,
  },
  productSearchMessage: {
    fontSize: theme.typography.bodySmall.fontSize,
    textAlign: 'center',
    marginVertical: theme.spacing.sm,
    padding: theme.spacing.sm,
    borderRadius: theme.borderRadius.sm,
  },
  successText: {
    color: theme.colors.success,
    backgroundColor: '#e6ffed', // Light green background
  },
  errorTextModal: { // Để phân biệt với errorText chung nếu có
    color: theme.colors.danger,
     backgroundColor: '#ffebee', // Light red background
  },
});