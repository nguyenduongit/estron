// src/services/storage.ts
import AsyncStorage from '@react-native-async-storage/async-storage';
// Đảm bảo đường dẫn đúng tới types của bạn
import { Quota, ProductionEntry, DailySupplementaryData, UserSelectedQuota, QuotaSetting } from '../types/data'; // SỬA ĐƯỜNG DẪN NÀY nếu cần
import 'react-native-get-random-values'; // Cần cho uuid
import { v4 as uuidv4 } from 'uuid';
import { supabase } from './supabase'; // Import supabase client

const QUOTAS_KEY = 'ESTRON_APP_QUOTAS_V1'; // Dành cho AsyncStorage cũ
const PRODUCTION_ENTRIES_KEY = 'ESTRON_APP_PRODUCTION_ENTRIES_V1';
const SUPPLEMENTARY_DATA_KEY = 'ESTRON_APP_SUPPLEMENTARY_DATA_V1';

// --- Quota Management (Định mức) AsyncStorage - CÓ THỂ SẼ KHÔNG DÙNG CHO SETTINGSCREEN NỮA ---
// ... (các hàm quản lý Quota AsyncStorage cũ: getQuotasFromStorage, saveQuotasToStorage, etc. giữ nguyên nhưng có thể không còn dùng cho SettingScreen) ...
export const getQuotasFromStorage = async (): Promise<Quota[]> => {
  try {
    const jsonValue = await AsyncStorage.getItem(QUOTAS_KEY);
    const quotas = jsonValue != null ? JSON.parse(jsonValue) : [];
    return quotas.sort((a: Quota, b: Quota) => a.order - b.order);
  } catch (e) {
    console.error("Lỗi khi tải định mức từ AsyncStorage:", e);
    return [];
  }
};

export const saveQuotasToStorage = async (quotas: Quota[]): Promise<boolean> => {
  try {
    const sortedAndOrderedQuotas = quotas.map((q, index) => ({ ...q, order: index }));
    const jsonValue = JSON.stringify(sortedAndOrderedQuotas);
    await AsyncStorage.setItem(QUOTAS_KEY, jsonValue);
    return true;
  } catch (e) {
    console.error("Lỗi khi lưu định mức vào AsyncStorage:", e);
    return false;
  }
};

export const addQuotaToStorage = async (newQuotaData: Omit<Quota, 'id' | 'order'>): Promise<Quota | null> => {
  try {
    const quotas = await getQuotasFromStorage();
    if (quotas.some(q => q.stageCode.trim().toLowerCase() === newQuotaData.stageCode.trim().toLowerCase())) {
      console.warn(`Mã công đoạn '${newQuotaData.stageCode}' đã tồn tại trong AsyncStorage.`);
      return null;
    }
    const newQuota: Quota = {
      ...newQuotaData,
      id: uuidv4(),
      order: quotas.length, 
    };
    const updatedQuotas = [...quotas, newQuota];
    await saveQuotasToStorage(updatedQuotas);
    return newQuota;
  } catch (e) {
    console.error("Lỗi khi thêm định mức vào AsyncStorage:", e);
    return null;
  }
};

export const deleteQuotaFromStorage = async (quotaIdToDelete: string): Promise<boolean> => {
  try {
    let quotas = await getQuotasFromStorage();
    quotas = quotas.filter(q => q.id !== quotaIdToDelete);
    return await saveQuotasToStorage(quotas);
  } catch (e) {
    console.error("Lỗi khi xóa định mức từ AsyncStorage:", e);
    return false;
  }
};

export const updateQuotaInStorage = async (updatedQuota: Quota): Promise<Quota | null> => {
    try {
        const quotas = await getQuotasFromStorage();
        const index = quotas.findIndex(q => q.id === updatedQuota.id);
        if (index === -1) {
            console.warn(`Không tìm thấy định mức với ID: ${updatedQuota.id} trong AsyncStorage để cập nhật.`);
            return null;
        }
        if (quotas.some(q => q.id !== updatedQuota.id && q.stageCode.trim().toLowerCase() === updatedQuota.stageCode.trim().toLowerCase())) {
            console.warn(`Mã công đoạn '${updatedQuota.stageCode}' đã tồn tại cho một định mức khác trong AsyncStorage.`);
            return null;
        }

        quotas[index] = { ...quotas[index], ...updatedQuota };
        await saveQuotasToStorage(quotas);
        return quotas[index];
    } catch (e) {
        console.error("Lỗi khi cập nhật định mức trong AsyncStorage:", e);
        return null;
    }
};


// --- Supabase Quota Settings & User Selected Quotas ---

/**
 * Lấy chi tiết một mã sản phẩm từ bảng quota_settings.
 * @param productCode Mã sản phẩm cần tra cứu.
 * @returns Chi tiết sản phẩm hoặc null nếu không tìm thấy.
 */
export const getQuotaSettingByProductCode = async (productCode: string): Promise<QuotaSetting | null> => {
  try {
    const { data, error } = await supabase
      .from('quota_settings')
      .select('*')
      .eq('product_code', productCode)
      .single();

    if (error) {
      // Không ném lỗi nếu lỗi là do không tìm thấy (PGRST116)
      if (error.code === 'PGRST116') {
        console.log(`Product code ${productCode} not found in quota_settings.`);
        return null;
      }
      console.error('Lỗi khi lấy chi tiết mã sản phẩm từ quota_settings:', error);
      throw error;
    }
    return data;
  } catch (e) {
    console.error('Exception khi lấy chi tiết mã sản phẩm:', e);
    return null;
  }
};

/**
 * Lấy danh sách các định mức đã chọn của người dùng.
 * @param userId ID của người dùng.
 * @returns Danh sách các định mức đã chọn, sắp xếp theo zindex.
 */
export const getUserSelectedQuotas = async (userId: string): Promise<UserSelectedQuota[]> => {
  if (!userId) {
    console.error("getUserSelectedQuotas: userId không được cung cấp.");
    return [];
  }
  try {
    const { data, error } = await supabase
      .from('user_selected_quotas')
      .select('*')
      .eq('user_id', userId)
      .order('zindex', { ascending: true });

    if (error) {
      console.error('Lỗi khi lấy danh sách định mức đã chọn của người dùng:', error);
      throw error;
    }
    return data || [];
  } catch (e) {
    console.error('Exception khi lấy danh sách định mức đã chọn:', e);
    return [];
  }
};

/**
 * Thêm một định mức mới vào danh sách đã chọn của người dùng.
 * @param userId ID của người dùng.
 * @param productCode Mã sản phẩm.
 * @param productName Tên sản phẩm.
 * @param zindex Thứ tự hiển thị.
 * @returns Định mức đã thêm hoặc null nếu lỗi.
 */
export const addUserSelectedQuota = async (
  userId: string,
  productCode: string,
  productName: string,
  zindex: number
): Promise<UserSelectedQuota | null> => {
  if (!userId || !productCode || !productName) {
    console.error("addUserSelectedQuota: Thiếu thông tin đầu vào quan trọng.");
    return null;
  }
  try {
    // Kiểm tra xem product_code đã tồn tại cho user_id này chưa
    const { data: existing, error: existingError } = await supabase
      .from('user_selected_quotas')
      .select('product_code')
      .eq('user_id', userId)
      .eq('product_code', productCode)
      .maybeSingle();

    if (existingError && existingError.code !== 'PGRST116') { // PGRST116 means 0 rows, which is fine
        console.error('Lỗi khi kiểm tra định mức đã tồn tại:', existingError);
        throw existingError;
    }

    if (existing) {
        console.warn(`Sản phẩm ${productCode} đã được người dùng ${userId} chọn.`);
        // Alert.alert("Thông báo", `Sản phẩm '${productCode}' đã có trong danh sách của bạn.`);
        return null; // Hoặc trả về existing nếu muốn
    }

    const { data, error } = await supabase
      .from('user_selected_quotas')
      .insert([{ user_id: userId, product_code: productCode, product_name: productName, zindex: zindex }])
      .select()
      .single();

    if (error) {
      console.error('Lỗi khi thêm định mức đã chọn:', error);
      throw error;
    }
    return data;
  } catch (e) {
    console.error('Exception khi thêm định mức đã chọn:', e);
    return null;
  }
};

/**
 * Xóa một định mức khỏi danh sách đã chọn của người dùng.
 * @param userId ID của người dùng.
 * @param productCode Mã sản phẩm cần xóa.
 * @returns True nếu thành công, false nếu thất bại.
 */
export const deleteUserSelectedQuota = async (userId: string, productCode: string): Promise<boolean> => {
  if (!userId || !productCode) {
    console.error("deleteUserSelectedQuota: Thiếu thông tin userId hoặc productCode.");
    return false;
  }
  try {
    const { error } = await supabase
      .from('user_selected_quotas')
      .delete()
      .eq('user_id', userId)
      .eq('product_code', productCode);

    if (error) {
      console.error('Lỗi khi xóa định mức đã chọn:', error);
      throw error;
    }
    return true;
  } catch (e) {
    console.error('Exception khi xóa định mức đã chọn:', e);
    return false;
  }
};

/**
 * Lưu lại thứ tự (zindex) của danh sách các định mức đã chọn.
 * @param userId ID của người dùng.
 * @param quotas Mảng các đối tượng chứa product_code và zindex mới.
 * @returns True nếu thành công, false nếu thất bại.
 */
export const saveUserSelectedQuotasOrder = async (
  userId: string,
  quotas: Array<{ product_code: string; zindex: number }>
): Promise<boolean> => {
  if (!userId || !quotas || quotas.length === 0) {
    console.warn("saveUserSelectedQuotasOrder: Không có dữ liệu để cập nhật hoặc thiếu userId.");
    return true; // Không có gì để làm, coi như thành công
  }
  try {
    // Supabase batch update
    const updates = quotas.map(q =>
      supabase
        .from('user_selected_quotas')
        .update({ zindex: q.zindex })
        .eq('user_id', userId)
        .eq('product_code', q.product_code)
    );

    const results = await Promise.all(updates);
    const errors = results.filter(res => res.error);

    if (errors.length > 0) {
      errors.forEach(err => console.error('Lỗi khi cập nhật thứ tự định mức:', err.error));
      // Ném lỗi đầu tiên để báo hiệu thất bại chung
      throw errors[0].error;
    }
    return true;
  } catch (e) {
    console.error('Exception khi cập nhật thứ tự định mức đã chọn:', e);
    return false;
  }
};


// --- Production Entry Management (Nhập sản lượng) ---
// ... (Giữ nguyên các hàm quản lý ProductionEntry) ...
export const getProductionEntriesFromStorage = async (): Promise<ProductionEntry[]> => {
  try {
    const jsonValue = await AsyncStorage.getItem(PRODUCTION_ENTRIES_KEY);
    return jsonValue != null ? JSON.parse(jsonValue) : [];
  } catch (e) {
    console.error("Lỗi khi tải dữ liệu sản lượng:", e);
    return [];
  }
};

export const saveProductionEntriesToStorage = async (entries: ProductionEntry[]): Promise<boolean> => {
  try {
    const jsonValue = JSON.stringify(entries);
    await AsyncStorage.setItem(PRODUCTION_ENTRIES_KEY, jsonValue);
    return true;
  } catch (e) {
    console.error("Lỗi khi lưu dữ liệu sản lượng:", e);
    return false;
  }
};

export const addOrUpdateProductionEntryInStorage = async (
  entryData: Omit<ProductionEntry, 'id'>
): Promise<ProductionEntry | null> => {
  try {
    let entries = await getProductionEntriesFromStorage();
    const existingEntryIndex = entries.findIndex(
      e => e.date === entryData.date && e.stageCode === entryData.stageCode
    );

    let resultEntry: ProductionEntry;

    if (existingEntryIndex > -1) {
      entries[existingEntryIndex].quantity = entryData.quantity;
      resultEntry = entries[existingEntryIndex];
    } else {
      const newEntry: ProductionEntry = {
        ...entryData,
        id: uuidv4(),
      };
      entries.push(newEntry);
      resultEntry = newEntry;
    }
    await saveProductionEntriesToStorage(entries);
    return resultEntry;
  } catch (e) {
    console.error("Lỗi khi thêm/cập nhật sản lượng:", e);
    return null;
  }
};

export const getProductionEntriesByDateFromStorage = async (date: string): Promise<ProductionEntry[]> => {
  const allEntries = await getProductionEntriesFromStorage();
  return allEntries.filter(entry => entry.date === date);
};

export const getProductionEntriesByDateRangeFromStorage = async (
  startDate: string, // YYYY-MM-DD
  endDate: string   // YYYY-MM-DD
): Promise<ProductionEntry[]> => {
  const allEntries = await getProductionEntriesFromStorage();
  return allEntries.filter(entry => entry.date >= startDate && entry.date <= endDate);
};

export const deleteProductionEntryFromStorage = async (entryId: string): Promise<boolean> => {
    try {
        let entries = await getProductionEntriesFromStorage();
        entries = entries.filter(e => e.id !== entryId);
        return await saveProductionEntriesToStorage(entries);
    } catch (e) {
        console.error("Lỗi khi xóa sản lượng:", e);
        return false;
    }
};

// --- Daily Supplementary Data Management (Nghỉ, Tăng ca, Họp) ---
// ... (Giữ nguyên các hàm quản lý DailySupplementaryData) ...
export const getAllSupplementaryDataFromStorage = async (): Promise<DailySupplementaryData[]> => {
  try {
    const jsonValue = await AsyncStorage.getItem(SUPPLEMENTARY_DATA_KEY);
    return jsonValue != null ? JSON.parse(jsonValue) : [];
  } catch (e) {
    console.error("Lỗi khi tải dữ liệu phụ trợ:", e);
    return [];
  }
};

export const saveAllSupplementaryDataToStorage = async (data: DailySupplementaryData[]): Promise<boolean> => {
  try {
    const jsonValue = JSON.stringify(data);
    await AsyncStorage.setItem(SUPPLEMENTARY_DATA_KEY, jsonValue);
    return true;
  } catch (e) {
    console.error("Lỗi khi lưu dữ liệu phụ trợ:", e);
    return false;
  }
};

export const addOrUpdateDailySupplementaryData = async (
  entryToUpdate: DailySupplementaryData
): Promise<DailySupplementaryData | null> => {
  try {
    let allSuppData = await getAllSupplementaryDataFromStorage();
    const existingEntryIndex = allSuppData.findIndex(e => e.date === entryToUpdate.date);

    if (existingEntryIndex > -1) {
      const existingEntry = allSuppData[existingEntryIndex];
      allSuppData[existingEntryIndex] = {
        ...existingEntry,
        ...entryToUpdate, 
      };
      if (entryToUpdate.leaveHours === null) allSuppData[existingEntryIndex].leaveHours = null;
      if (entryToUpdate.overtimeHours === null) allSuppData[existingEntryIndex].overtimeHours = null;
      if (entryToUpdate.meetingMinutes === null) allSuppData[existingEntryIndex].meetingMinutes = null;

    } else {
      allSuppData.push(entryToUpdate);
    }
    allSuppData = allSuppData.filter(entry =>
        entry.leaveHours != null || entry.overtimeHours != null || entry.meetingMinutes != null
    );

    await saveAllSupplementaryDataToStorage(allSuppData);
    const finalEntry = allSuppData.find(e => e.date === entryToUpdate.date);
    return finalEntry || null;

  } catch (e) {
    console.error("Lỗi khi thêm/cập nhật dữ liệu phụ trợ:", e);
    return null;
  }
};

export const getSupplementaryDataByDateFromStorage = async (date: string): Promise<DailySupplementaryData | null> => {
  const allSuppData = await getAllSupplementaryDataFromStorage();
  return allSuppData.find(entry => entry.date === date) || null;
};

export const getSupplementaryDataByDateRangeFromStorage = async (
  startDate: string, // YYYY-MM-DD
  endDate: string   // YYYY-MM-DD
): Promise<DailySupplementaryData[]> => {
  const allSuppData = await getAllSupplementaryDataFromStorage();
  return allSuppData.filter(entry => entry.date >= startDate && entry.date <= endDate);
};

// Hàm tiện ích để xóa toàn bộ dữ liệu (dùng cho testing)
export const clearAllData = async () => {
    try {
        await AsyncStorage.removeItem(QUOTAS_KEY);
        await AsyncStorage.removeItem(PRODUCTION_ENTRIES_KEY);
        await AsyncStorage.removeItem(SUPPLEMENTARY_DATA_KEY);
        
        // THÊM LỆNH XÓA DỮ LIỆU SUPABASE (NẾU CẦN CHO TESTING, CẨN THẬN KHI DÙNG)
        // const { data: { user } } = await supabase.auth.getUser();
        // if (user) {
        //   await supabase.from('user_selected_quotas').delete().eq('user_id', user.id);
        //   // Thêm các lệnh xóa khác cho các bảng supabase nếu cần
        // }
        console.log("Đã xóa toàn bộ dữ liệu AsyncStorage.");
    } catch (e) {
        console.error("Lỗi khi xóa toàn bộ dữ liệu:", e);
    }
}