// src/navigation/AppNavigator.tsx
import React from 'react';
// Bỏ import NavigationContainer nếu không dùng ở đây
// import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator, StackNavigationProp } from '@react-navigation/stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { TouchableOpacity, Platform } from 'react-native';

// Import các màn hình
import ProductScreen from '../screens/InputTab/ProductScreen'; //
import InputScreen from '../screens/InputTab/InputScreen'; //
import SettingScreen from '../screens/InputTab/SettingScreen'; //
import StatisticsScreen from '../screens/StatisticsTab/StatisticsScreen'; //

// Import types
import { InputStackNavigatorParamList, BottomTabNavigatorParamList } from './types'; //
import { theme } from '../theme'; //

const InputTabStack = createStackNavigator<InputStackNavigatorParamList>();
const StatisticsTabStack = createStackNavigator();
const Tab = createBottomTabNavigator<BottomTabNavigatorParamList>();

const commonStackScreenOptions = {
  headerStyle: { backgroundColor: theme.colors.primary },
  headerTintColor: theme.colors.white,
  headerTitleStyle: { fontWeight: 'bold' as 'bold' },
};

function InputStack() {
  return (
    <InputTabStack.Navigator
      initialRouteName="ProductList"
      screenOptions={commonStackScreenOptions}
    >
      <InputTabStack.Screen
        name="ProductList"
        component={ProductScreen}
        options={({ navigation }: { navigation: StackNavigationProp<InputStackNavigatorParamList, 'ProductList'> }) => ({
          title: 'Sản Lượng Estron',
          headerRight: () => (
            <TouchableOpacity
              onPress={() => navigation.navigate('Settings')}
              style={{
                marginRight: Platform.OS === 'ios' ? theme.spacing.sm : theme.spacing.md,
                padding: theme.spacing.xs,
              }}
            >
              <Ionicons name="settings-outline" size={24} color={theme.colors.white} />
            </TouchableOpacity>
          ),
        })}
      />
      <InputTabStack.Screen
        name="InputDetails"
        component={InputScreen}
      />
      <InputTabStack.Screen
        name="Settings"
        component={SettingScreen}
        options={{ title: 'Cài Đặt Định Mức' }}
      />
    </InputTabStack.Navigator>
  );
}

function StatisticsStack() {
  return (
    <StatisticsTabStack.Navigator
      screenOptions={commonStackScreenOptions}
    >
      <StatisticsTabStack.Screen
        name="StatisticsRoot"
        component={StatisticsScreen}
        options={{ title: 'Thống Kê Chung' }}
      />
    </StatisticsTabStack.Navigator>
  );
}

export default function AppNavigator() {
  // KHÔNG còn NavigationContainer ở đây
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: React.ComponentProps<typeof Ionicons>['name'] = 'alert-circle-outline';

          if (route.name === 'InputTab') {
            iconName = focused ? 'create' : 'create-outline';
          } else if (route.name === 'StatisticsTab') {
            iconName = focused ? 'stats-chart' : 'stats-chart-outline';
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: theme.colors.secondary,
        headerShown: false,
        tabBarStyle: {
          backgroundColor: theme.colors.white,
          borderTopColor: theme.colors.borderColor,
        }
      })}
    >
      <Tab.Screen
        name="InputTab"
        component={InputStack}
        options={{ title: 'Nhập liệu' }}
      />
      <Tab.Screen
        name="StatisticsTab"
        component={StatisticsStack}
        options={{ title: 'Thống kê' }}
      />
    </Tab.Navigator>
  );
}