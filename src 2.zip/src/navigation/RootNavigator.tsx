// src/navigation/RootNavigator.tsx
import React, { useState, useEffect } from 'react';
import {
  NavigationContainer,
  DefaultTheme,
} from '@react-navigation/native';
import { NavigationIndependentTree } from '@react-navigation/native';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { supabase } from '../services/supabase'; //
import { AuthNavigator } from './AuthNavigator'; //
import  AppNavigator  from './AppNavigator'; //
import { Session } from '@supabase/supabase-js';
import { theme as appCustomTheme } from '../theme'; 

export default function RootNavigator() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!supabase) {
      console.error('[RootNavigator.tsx] Supabase client is not initialized.');
      setLoading(false);
      return;
    }
    supabase.auth.getSession().then(({ data: { session: currentSession } }) => {
      setSession(currentSession);
      setLoading(false);
    }).catch((error) => {
      console.error("Error getting session:", error);
      setLoading(false);
    });

    const { data: authListener } = supabase.auth.onAuthStateChange(
      (_event, currentSession) => {
        setSession(currentSession);
        if (_event === 'INITIAL_SESSION') {
            setLoading(false);
        }
      }
    );

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, []);

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: appCustomTheme.colors.background }]}>
        <ActivityIndicator size="large" color={appCustomTheme.colors.primary} />
      </View>
    );
  }

  // Tùy chỉnh theme cho NavigationContainer từ theme của bạn
  const baseNavigationTheme = appCustomTheme

  const navigationTheme = {
    ...baseNavigationTheme,
    dark: false, // or true if your theme is dark
    colors: {
      ...baseNavigationTheme.colors,
      primary: appCustomTheme.colors.primary,
      background: appCustomTheme.colors.background,
      card: appCustomTheme.colors.cardBackground, // Hoặc background nếu không có card
      text: appCustomTheme.colors.text, // Hoặc onBackground
      border: appCustomTheme.colors.borderColor,
      notification: appCustomTheme.colors.primary,
    },
    fonts: DefaultTheme.fonts, // Use fonts from DefaultTheme or define your own
  };

  return (
    <NavigationIndependentTree>
      <NavigationContainer theme={navigationTheme}>
        {session && session.user ? <AppNavigator /> : <AuthNavigator />}
      </NavigationContainer>
    </NavigationIndependentTree>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});